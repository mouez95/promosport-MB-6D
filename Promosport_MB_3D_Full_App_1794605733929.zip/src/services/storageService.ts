/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NotificationSettings, UserBetSlip, AppSettings } from '../types/promosport';

const STORAGE_KEY = 'promosport_tunisie_settings_v1';
const SLIPS_STORAGE_KEY = 'promosport_user_slips_v1';
const APP_SETTINGS_KEY = 'promosport_app_settings_v1';

export const DEFAULT_APP_SETTINGS: AppSettings = {
  appName: 'بروموسبور تونس - MB Football',
  packageId: 'com.promosport.tunisie.mb',
  phoneNumber: '51155580',
  concoursNumber: 934,
  columnRate: 0.150,
  baseFee: 0.250,
  enableSlipsHistory: true,
};

export function loadAppSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(APP_SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<AppSettings>;
      const merged: AppSettings = { ...DEFAULT_APP_SETTINGS, ...parsed };
      if (!merged.concoursNumber || merged.concoursNumber < DEFAULT_APP_SETTINGS.concoursNumber) {
        merged.concoursNumber = DEFAULT_APP_SETTINGS.concoursNumber;
        saveAppSettings(merged);
      }
      return merged;
    }
  } catch (err) {
    console.warn('Could not read app settings from localStorage', err);
  }
  return DEFAULT_APP_SETTINGS;
}

export function saveAppSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.warn('Could not save app settings to localStorage', err);
  }
}

/**
 * Loads user saved bet slips. Starts strictly empty so no virtual/dummy slips are shown.
 */
export function loadUserSlips(): UserBetSlip[] {
  try {
    const raw = localStorage.getItem(SLIPS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Could not read user slips from localStorage', err);
  }
  return [];
}

/**
 * Saves user bet slips to persistent localStorage
 */
export function saveUserSlips(slips: UserBetSlip[]): void {
  try {
    localStorage.setItem(SLIPS_STORAGE_KEY, JSON.stringify(slips));
  } catch (err) {
    console.warn('Could not save user slips to localStorage', err);
  }
}

/**
 * Adds or updates a slip, ensuring sequential numbering
 */
export function saveOrUpdateSlip(slip: UserBetSlip): UserBetSlip[] {
  const current = loadUserSlips();
  const index = current.findIndex((s) => s.id === slip.id);
  let updated: UserBetSlip[];
  if (index >= 0) {
    updated = [...current];
    updated[index] = { ...slip, updatedAt: new Date().toISOString() };
  } else {
    // Number sequentially: قصاصة رقم 1, قصاصة رقم 2...
    const slipNumber = current.length + 1;
    const namedSlip: UserBetSlip = {
      ...slip,
      name: slip.name && slip.name.trim() !== '' ? slip.name : `قصاصة مسجلة رقم ${slipNumber}`,
      createdAt: slip.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    // Keep in chronological order (appended or prepended, consistently indexed)
    updated = [...current, namedSlip];
  }
  saveUserSlips(updated);
  return updated;
}

/**
 * Deletes a slip by ID
 */
export function deleteSlip(slipId: string): UserBetSlip[] {
  const current = loadUserSlips();
  const filtered = current.filter((s) => s.id !== slipId);
  // Re-number remaining slips in strict sequential order (قصاصة مسجلة رقم 1, رقم 2, رقم 3...)
  const renumbered = filtered.map((slip, index) => ({
    ...slip,
    name: `قصاصة مسجلة رقم ${index + 1}`
  }));
  saveUserSlips(renumbered);
  return renumbered;
}

/**
 * Clears all user bet slips from persistent localStorage
 */
export function clearAllSlips(): UserBetSlip[] {
  saveUserSlips([]);
  return [];
}


export const DEFAULT_SETTINGS: NotificationSettings = {
  notifyNewGrille: true,
  notifyOfficialResults: true,
  notifyJackpotRollover: true,
  notifyClosingCountdown: true,
  soundEnabled: true,
  pushNotificationsEnabled: false,
  durationSeconds: 10,
  checkIntervalMinutes: 15,
  lastSyncTime: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
  autoUpdateActive: true,
};

export function loadSettings(): NotificationSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.warn('Could not read settings from localStorage', err);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: NotificationSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    console.warn('Could not write settings to localStorage', err);
  }
}

/**
 * Download configuration and full prompt backup as JSON
 */
export function exportBackupJSON(settings: NotificationSettings, extraData?: unknown): void {
  const fullBackup = {
    appName: "بروموسبور تونس - Promosport Tunisie 3D",
    version: "1.0.0",
    exportDate: new Date().toISOString(),
    systemPromptSpecification: `[بروموسبور تونس]
واجهة ثلاثية الأبعاد تفاعلية فائقة السلاسة مستوحاة من الهوية الرياضية التونسية والبروموسبور:
1. كرة قدم ثلاثية الأبعاد في وسط الشاشة بنسبة 50% في المركز الهندسي الدقيق للشاشة بدقة فائقة 3K Ultra-HD
- دوران من اليمين الى اليسار بدون أي انقطاع وبسلاسة مطلقة وخفة تامة.
- إمكانية تكبير وتصغير الكرة و دورانها من فوق او من تحت بحرية عبر اللمس بإصبعين أو بإصبع واحد أو عجلة الفأرة.
- دمج لوحات المسابقات الثلاث الأخيرة (932، 931، 930) مباشرة في وجوه رقعات كرة القدم مع رقم القصاصة، التاريخ، القيمة المالية، عدد الفائزين ونصيب كل فائز.
2. خلفية سوداء حالكة مع نجوم حادة ومشعة وشهب خاطفة، وشعار الجامعة والبروموسبور المضيء باليمين، والشعار المذهب المشع في الأسفل.
3. منظومة تنبيهات متقدمة مخصصة مع حفظ واستيراد وتنزيل البرومبت والإعدادات JSON.
- أرقام الجوائز والفائزين معروضة من اليسار إلى اليمين LTR.`,
    settings,
    competitionsTracked: [933, 932, 931],
    dataSource: "http://www.promosportplus.com/grille_int_result.php",
    metadata: extraData || {}
  };

  const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `promosport_tunisie_backup_${Date.now()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Import configuration from JSON file
 */
export function importBackupJSON(file: File): Promise<NotificationSettings> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        const importedSettings = parsed.settings || parsed;
        const merged: NotificationSettings = {
          ...DEFAULT_SETTINGS,
          ...importedSettings
        };
        saveSettings(merged);
        resolve(merged);
      } catch (err) {
        reject(new Error('ملف JSON غير صالح أو تالف'));
      }
    };
    reader.onerror = () => reject(new Error('فشلت قراءة الملف'));
    reader.readAsText(file);
  });
}
