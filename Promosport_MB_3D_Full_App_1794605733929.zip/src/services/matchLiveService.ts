/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeeklyConcours, WeeklyConcoursMatch } from '../types/promosport';

// Total duration of a football match window from kickoff to full-time (45 + 15 HT + 45 + 10 stoppage = 115 min)
const MATCH_DURATION_MS = 115 * 60 * 1000;

/**
 * Safely extracts home and away numeric scores from either explicit fields
 * (`scoreHome`/`scoreAway`) or formatted strings (`"2 - 1"`, `"0 : 2"`).
 */
export function parseMatchScore(match: WeeklyConcoursMatch): { home: string; away: string } | null {
  if (match.scoreHome !== undefined && match.scoreAway !== undefined && match.scoreHome !== '' && match.scoreAway !== '') {
    return { home: String(match.scoreHome), away: String(match.scoreAway) };
  }
  if (match.score && match.score !== '- - -') {
    const parts = match.score.split(/[-:]/).map((s) => s.trim());
    if (parts.length === 2 && /^\d+$/.test(parts[0]) && /^\d+$/.test(parts[1])) {
      return { home: parts[0], away: parts[1] };
    }
  }
  return null;
}

/**
 * Computes official Promosport sign ('1' | 'X' | '2') from numeric scores.
 */
export function computeResultSign(homeScore: number, awayScore: number): '1' | 'X' | '2' {
  if (homeScore > awayScore) return '1';
  if (homeScore < awayScore) return '2';
  return 'X';
}

/**
 * Translates elapsed real minutes since kickoff into display football minute (`1'`..`45'`, `HT`, `46'`..`90'+`).
 */
function formatFootballMinute(elapsedRealMinutes: number): { label: string; gameMinute: number } {
  if (elapsedRealMinutes < 1) {
    return { label: "1'", gameMinute: 1 };
  }
  if (elapsedRealMinutes <= 45) {
    return { label: `${elapsedRealMinutes}'`, gameMinute: elapsedRealMinutes };
  }
  if (elapsedRealMinutes <= 60) {
    return { label: 'استراحة', gameMinute: 45 };
  }
  const secondHalfMinute = 45 + (elapsedRealMinutes - 60);
  if (secondHalfMinute <= 90) {
    return { label: `${secondHalfMinute}'`, gameMinute: secondHalfMinute };
  }
  return { label: `90+${Math.min(10, secondHalfMinute - 90)}'`, gameMinute: 90 };
}

/**
 * Evaluates a single match's real-time status, live score (starting 0 - 0 at kickoff),
 * pulsing green live minute, and finished final score + official 1/X/2 result.
 */
export function evaluateMatchRealTime(
  match: WeeklyConcoursMatch,
  nowMs: number,
  simulatedKickoffStartedAtMs: number | null = null
): WeeklyConcoursMatch {
  const parsedFinal = parseMatchScore(match);

  // 1. If the match is explicitly finished and has final scores, normalize and return finished state
  if (match.status === 'finished' && parsedFinal) {
    const h = Number(parsedFinal.home);
    const a = Number(parsedFinal.away);
    return {
      ...match,
      status: 'finished',
      scoreHome: parsedFinal.home,
      scoreAway: parsedFinal.away,
      score: `${parsedFinal.home} - ${parsedFinal.away}`,
      result: match.result || computeResultSign(h, a),
      liveMinute: undefined,
    };
  }

  // 2. Real-time clock evaluation based on match.kickoffTimestamp
  if (match.kickoffTimestamp > 0) {
    const endTimestamp = match.kickoffTimestamp + MATCH_DURATION_MS;

    // 2a. Match has FINISHED in real time
    if (nowMs >= endTimestamp) {
      const finalHome = parsedFinal ? parsedFinal.home : '0';
      const finalAway = parsedFinal ? parsedFinal.away : '0';
      const h = Number(finalHome);
      const a = Number(finalAway);
      return {
        ...match,
        status: 'finished',
        scoreHome: finalHome,
        scoreAway: finalAway,
        score: `${finalHome} - ${finalAway}`,
        result: match.result || computeResultSign(h, a),
        liveMinute: undefined,
      };
    }

    // 2b. Match is LIVE right now in real time: starts 0 - 0 at kickoff and updates goals live!
    if (nowMs >= match.kickoffTimestamp && nowMs < endTimestamp) {
      const elapsedRealMinutes = Math.floor((nowMs - match.kickoffTimestamp) / 60000);
      const { label, gameMinute } = formatFootballMinute(elapsedRealMinutes);

      let liveHome = 0;
      let liveAway = 0;
      if (match.liveEvents && match.liveEvents.length > 0) {
        for (const ev of match.liveEvents) {
          if (ev.minute <= gameMinute) {
            if (ev.team === 'home') liveHome++;
            else liveAway++;
          }
        }
      }

      return {
        ...match,
        status: 'live',
        scoreHome: String(liveHome),
        scoreAway: String(liveAway),
        score: `${liveHome} - ${liveAway}`,
        liveMinute: label,
        result: null, // Official 1/X/2 result finalizes at full-time
      };
    }
  }

  // 3. Optional manual live simulation override for upcoming matches (1 second = 1 match minute, starting 0 - 0)
  if (simulatedKickoffStartedAtMs !== null) {
    const simElapsedSeconds = Math.max(0, Math.floor((nowMs - simulatedKickoffStartedAtMs) / 1000));
    const simMatchMinute = Math.min(95, simElapsedSeconds + 1);

    if (simMatchMinute > 92) {
      const finalHome = parsedFinal ? parsedFinal.home : '0';
      const finalAway = parsedFinal ? parsedFinal.away : '0';
      const h = Number(finalHome);
      const a = Number(finalAway);
      return {
        ...match,
        status: 'finished',
        scoreHome: finalHome,
        scoreAway: finalAway,
        score: `${finalHome} - ${finalAway}`,
        result: match.result || computeResultSign(h, a),
        liveMinute: undefined,
      };
    }

    let liveHome = 0;
    let liveAway = 0;
    if (match.liveEvents && match.liveEvents.length > 0) {
      for (const ev of match.liveEvents) {
        if (ev.minute <= simMatchMinute) {
          if (ev.team === 'home') liveHome++;
          else liveAway++;
        }
      }
    }

    return {
      ...match,
      status: 'live',
      scoreHome: String(liveHome),
      scoreAway: String(liveAway),
      score: `${liveHome} - ${liveAway}`,
      liveMinute: simMatchMinute > 90 ? `90+${simMatchMinute - 90}'` : `${simMatchMinute}'`,
      result: null,
    };
  }

  // 4. Match is scheduled and hasn't started yet
  return {
    ...match,
    status: 'scheduled',
    score: '- - -',
    scoreHome: undefined,
    scoreAway: undefined,
    liveMinute: undefined,
    result: null,
  };
}

/**
 * Evaluates all matches of a WeeklyConcours against current time.
 */
export function evaluateConcoursRealTime(
  concours: WeeklyConcours,
  nowMs: number,
  simulatedKickoffStartedAtMs: number | null = null
): WeeklyConcours {
  return {
    ...concours,
    matches: concours.matches.map((m) =>
      evaluateMatchRealTime(m, nowMs, simulatedKickoffStartedAtMs)
    ),
  };
}

/**
 * Checks whether all 13 matches in the concours have finished at full-time.
 */
export function isConcoursCompletelyFinished(
  concours: WeeklyConcours,
  nowMs: number
): boolean {
  const evaluated = evaluateConcoursRealTime(concours, nowMs, null);
  return (
    evaluated.matches.length > 0 &&
    evaluated.matches.every((m) => m.status === 'finished')
  );
}
