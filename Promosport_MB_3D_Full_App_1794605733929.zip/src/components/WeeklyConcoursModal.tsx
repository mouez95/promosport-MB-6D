/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  ArrowRight,
  Lock,
  Smartphone,
  LayoutGrid,
  Ticket,
  CheckCircle2,
  Trash2,
  Edit3,
  Save,
  Settings,
  Download,
  Check,
  FolderArchive,
  Coins,
  Receipt,
  Hash,
  Package,
  PhoneCall,
  CheckSquare,
  RefreshCw,
} from 'lucide-react';
import {
  WeeklyConcours,
  WeeklyConcoursMatch,
  UserBetSlip,
  AppSettings,
  PromosportGrille,
} from '../types/promosport';
import {
  INITIAL_WEEKLY_CONCOURS,
  INITIAL_GRILLES,
  getOrderedRecentTirageGrilles,
} from '../services/promosportData';
import {
  loadUserSlips,
  saveOrUpdateSlip,
  deleteSlip,
  clearAllSlips,
  loadAppSettings,
  saveAppSettings,
  DEFAULT_APP_SETTINGS,
} from '../services/storageService';
import { calculatePromosportPrice } from '../services/pricingService';
import { evaluateConcoursRealTime } from '../services/matchLiveService';
import { audioService } from '../services/audioService';
import { MbLogo } from './MbLogo';
import { BroadcastScoreboardMatch } from './BroadcastScoreboardMatch';
import { PromosportUnifiedBadge } from './PromosportUnifiedBadge';
import { Grille3DWheelView } from './Grille3DWheelView';
import { SavedSlipFullPageView } from './SavedSlipFullPageView';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { AppInstallPromptHub } from './AppInstallPromptHub';
import confetti from 'canvas-confetti';

interface WeeklyConcoursModalProps {
  isOpen: boolean;
  onClose: () => void;
  concours: WeeklyConcours;
  onUpdateConcours?: (updated: WeeklyConcours) => void;
  grilles?: PromosportGrille[];
  onRefreshSync?: () => Promise<void> | void;
  initialTab?: 'grille' | 'tirage' | 'settings' | 'apk';
  appSettings?: AppSettings;
  onUpdateAppSettings?: (settings: AppSettings) => void;
}

// Arabic Team Name Translations
const ARABIC_TEAM_NAMES: Record<string, string> = {
  'Italie': 'إيطاليا',
  'France': 'فرنسا',
  'Turquie': 'تركيا',
  'Belgique': 'بلجيكا',
  'Tcheque': 'التشيك',
  'Espagne': 'إسبانيا',
  'Angleterre': 'إنجلترا',
  'Croatie': 'كرواتيا',
  'Albanie': 'ألبانيا',
  'Finlande': 'فنلندا',
  'Montenegro': 'الجبل الأسود',
  'Lettonie': 'لاتفيا',
  'Armenie': 'أرمينيا',
  'Chypre': 'قبرص',
  'Guinee Equatoriale': 'غينيا الاستوائية',
  'Zimbabwe': 'زيمبابوي',
  'Madagascar': 'مدغشقر',
  'Guinee Bissau': 'غينيا بيساو',
  'Cote D ivoire': 'كوت ديفوار',
  'Gambie': 'غامبيا',
  'RD Congo': 'الكونغو الديمقراطية',
  'Sierra Leone': 'سيراليون',
  'Benin': 'بنين',
  'Afrique Centrale': 'إفريقيا الوسطى',
  'Senegal': 'السنغال',
  'Soudan': 'السودان',
  // --- Concours 934 Teams ---
  'Portugal': 'البرتغال',
  'Danemark': 'الدنمارك',
  'Norvege': 'النرويج',
  'Pays de Galles': 'ويلز',
  'Irlande du Nord': 'أيرلندا الشمالية',
  'Ukraine': 'أوكرانيا',
  'Autriche': 'النمسا',
  'Irlande': 'أيرلندا',
  'Roumanie': 'رومانيا',
  'Pologne': 'بولندا',
  'Suede': 'السويد',
  'Bosnie herzegovine': 'البوسنة والهرسك',
  'Georgie': 'جورجيا',
  'Hongrie': 'المجر',
  'Ouganda': 'أوغندا',
  'Botswana': 'بوتسوانا',
  'Algerie': 'الجزائر',
  'Togo': 'توغو',
  'Real Oviedo': 'ريال أوفييدو',
  'Girona': 'جيرونا',
  'Mallorca': 'مايوركا',
  'Cordoba': 'قرطبة',
  'Real Sociedad B': 'ريال سوسيداد ب',
  'Sporting Gijon': 'سبورتينغ خيخون',
  'Almeria': 'ألميريا',
  'FC Andorra': 'أندورا',
  'CHELSEA': 'تشيلسي',
  'LOS ANGELES': 'لوس أنجلوس',
  'FLUMINENSE': 'فلومينينسي',
  'DORTMUND': 'بوروسيا دورتموند',
  'BOCA JUNIORS': 'بوكا جونيورز',
  'BENFICA': 'بنفيكا',
  'PRANCIS': 'فرنسا',
  'POLANDIA': 'بولندا',
  'GEORGIA': 'جورجيا',
  'PORTUGAL': 'البرتغال',
};

export const WeeklyConcoursModal: React.FC<WeeklyConcoursModalProps> = ({
  isOpen,
  onClose,
  concours,
  grilles = INITIAL_GRILLES,
  onRefreshSync,
  initialTab = 'grille',
  appSettings: initialAppSettings,
  onUpdateAppSettings,
}) => {
  // Active competition synced from parent concours (default international Concours No 934)
  const [activeConcours, setActiveConcours] = useState<WeeklyConcours>(
    concours || INITIAL_WEEKLY_CONCOURS
  );
  const prevConcoursNumRef = useRef<number>((concours || INITIAL_WEEKLY_CONCOURS).number);

  useEffect(() => {
    if (concours) {
      if (prevConcoursNumRef.current !== concours.number) {
        // Silent rollover: reset temporary selections when a new concours arrives
        setCurrentSelections({});
        setEditingSlipId(null);
        prevConcoursNumRef.current = concours.number;
      }
      setActiveConcours(concours);
    }
  }, [concours]);

  // Bottom navigation: 'grille' | 'tirage' | 'settings' | 'apk'
  const [activeBottomNav, setActiveBottomNav] = useState<'grille' | 'tirage' | 'settings' | 'apk'>(initialTab);

  // Latest 3 previous completed grilles ordered descending (e.g. 933, 932, 931), excluding active concours
  const recentGrilles = useMemo(
    () => getOrderedRecentTirageGrilles(grilles, activeConcours.number),
    [grilles, activeConcours.number]
  );

  // Selected concours in Tirage tab (933 / 932 / 931)
  const [selectedTirageNumber, setSelectedTirageNumber] = useState<number>(
    recentGrilles[0]?.number || 933
  );

  useEffect(() => {
    if (recentGrilles.length > 0 && !recentGrilles.some((g) => g.number === selectedTirageNumber)) {
      setSelectedTirageNumber(recentGrilles[0].number);
    }
  }, [recentGrilles, selectedTirageNumber]);

  const activeTirage = useMemo(
    () => recentGrilles.find((g) => g.number === selectedTirageNumber) || recentGrilles[0],
    [recentGrilles, selectedTirageNumber]
  );

  const [isRefreshingTirage, setIsRefreshingTirage] = useState<boolean>(false);

  const handleRefreshTirageFromSite = async () => {
    if (isRefreshingTirage) return;
    setIsRefreshingTirage(true);
    try {
      if (onRefreshSync) {
        await onRefreshSync();
      }
    } finally {
      setIsRefreshingTirage(false);
    }
  };

  // Automatically sync official results & payouts from promosportplus.com/grille_int_result.php when opening Tirage
  useEffect(() => {
    if (isOpen && activeBottomNav === 'tirage' && onRefreshSync) {
      void onRefreshSync();
    }
  }, [isOpen, activeBottomNav, onRefreshSync]);

  // Sub-tabs in Grille view: 'mondiale' | 'nationale' | 'slips'
  const [grilleSubTab, setGrilleSubTab] = useState<'mondiale' | 'nationale' | 'slips'>('mondiale');

  // National check states (when no national concours is published)
  const [isCheckingNational, setIsCheckingNational] = useState<boolean>(false);
  const [lastNationalCheckTime, setLastNationalCheckTime] = useState<string>('اليوم (تحديث مستمر)');

  const handleRefreshNational = async () => {
    audioService.playClick();
    setIsCheckingNational(true);
    try {
      if (onRefreshSync) {
        await onRefreshSync();
      }
    } finally {
      setIsCheckingNational(false);
      const timeStr = new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastNationalCheckTime(`اليوم في ${timeStr}`);
      audioService.playChime();
      setSlipNoticeMessage(
        'تم التحقق بنجاح من موقع promosportplus.com — القصاصة الوطنية غير منشورة حالياً.'
      );
      setTimeout(() => setSlipNoticeMessage(null), 4000);
    }
  };

  // Language toggle: AR / FR
  const [lang, setLang] = useState<'AR' | 'FR'>('AR');

  // Floating glass ribbon open/close state in Grille (auto-closes on scroll, opens manually)
  const [isGrilleRibbonOpen, setIsGrilleRibbonOpen] = useState<boolean>(true);

  // Fast shimmering golden ray strictly around clicked icon perimeter in خانة القصاصة
  const [tapFlashes, setTapFlashes] = useState<
    { id: number; left: number; top: number; width: number; height: number; radius: string }[]
  >([]);

  const triggerGrilleIconFlash = (e: React.MouseEvent<HTMLDivElement>) => {
    if (activeBottomNav !== 'grille' || selectedFullSlip) return;
    const targetEl = (e.target as HTMLElement | null)?.closest(
      'button, [role="button"], [data-flash-icon]'
    ) as HTMLElement | null;
    if (!targetEl) return;

    // Outer shimmering golden ray glow around the icon itself
    targetEl.classList.remove('grille-icon-flash');
    void targetEl.offsetWidth;
    targetEl.classList.add('grille-icon-flash');
    window.setTimeout(() => {
      targetEl.classList.remove('grille-icon-flash');
    }, 270);

    // Exact perimeter golden halo overlay that wraps around the icon edges and fades out
    const rect = targetEl.getBoundingClientRect();
    const radius = window.getComputedStyle(targetEl).borderRadius || '12px';
    const flashId = Date.now() + Math.random();

    setTapFlashes((prev) => [
      ...prev.slice(-6),
      {
        id: flashId,
        left: rect.left - 4,
        top: rect.top - 4,
        width: rect.width + 8,
        height: rect.height + 8,
        radius,
      },
    ]);
    window.setTimeout(() => {
      setTapFlashes((prev) => prev.filter((item) => item.id !== flashId));
    }, 280);
  };

  // Live clock
  const [liveClock, setLiveClock] = useState<string>('18:00:00');

  // App Settings state
  const [settings, setSettings] = useState<AppSettings>(() => initialAppSettings || loadAppSettings());
  const [settingsSavedAlert, setSettingsSavedAlert] = useState<boolean>(false);

  // Slips from storage (strictly NO virtual/dummy slips)
  const [userSlips, setUserSlips] = useState<UserBetSlip[]>(() => loadUserSlips());
  const [editingSlipId, setEditingSlipId] = useState<string | null>(null);
  const [slipNoticeMessage, setSlipNoticeMessage] = useState<string | null>(null);

  // Selected choices map: matchId -> array of choices ('1' | 'X' | '2')
  const [currentSelections, setCurrentSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>({});

  // Expanded slip in Saved Slips page
  const [expandedSlipId, setExpandedSlipId] = useState<string | null>(null);
  // Full-page active slip view
  const [selectedFullSlip, setSelectedFullSlip] = useState<UserBetSlip | null>(null);

  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [goalFlashMatchIds, setGoalFlashMatchIds] = useState<Record<number, number>>({});
  const prevScoresRef = useRef<Record<number, { h: number; a: number; status: string }> | null>(null);

  // ALWAYS ACTIVE: Continuous 1-second ticker updating clock, live minutes & goal scores
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setNowMs(now.getTime());
      setLiveClock(now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Real-time evaluated concours (finished matches show final scores & results, live matches start at 0-0 & pulse green)
  const liveConcours = useMemo(
    () => evaluateConcoursRealTime(activeConcours, nowMs, null),
    [activeConcours, nowMs]
  );

  // Detect live goal scored every second and flash that match card
  useEffect(() => {
    const nextScores: Record<number, { h: number; a: number; status: string }> = {};
    const scoredNow: number[] = [];

    liveConcours.matches.forEach((m) => {
      const h = Number(m.scoreHome ?? 0);
      const a = Number(m.scoreAway ?? 0);
      nextScores[m.id] = { h, a, status: m.status };

      const prev = prevScoresRef.current?.[m.id];
      if (prev && prev.status === 'live' && m.status === 'live' && (h > prev.h || a > prev.a)) {
        scoredNow.push(m.id);
      }
    });

    prevScoresRef.current = nextScores;

    if (scoredNow.length > 0) {
      audioService.playChime();
      const stamp = Date.now();
      setGoalFlashMatchIds((prev) => {
        const updated = { ...prev };
        scoredNow.forEach((id) => {
          updated[id] = stamp;
        });
        return updated;
      });
      scoredNow.forEach((id) => {
        window.setTimeout(() => {
          setGoalFlashMatchIds((prev) => {
            if (prev[id] !== stamp) return prev;
            const copy = { ...prev };
            delete copy[id];
            return copy;
          });
        }, 4500);
      });
    }
  }, [liveConcours]);

  // Automatic betting & editing lock:
  // Locked automatically from kickoff of the 1st match until end of last match / appearance of a new concours.
  const hasFirstMatchStarted = useMemo(
    () => liveConcours.matches.some((m) => m.status === 'live' || m.status === 'finished'),
    [liveConcours]
  );
  const isBettingLocked = hasFirstMatchStarted;

  // Sync state on opening
  useEffect(() => {
    if (isOpen) {
      setUserSlips(loadUserSlips());
      const loaded = initialAppSettings || loadAppSettings();
      setSettings(loaded);
      if (initialTab) {
        setActiveBottomNav(initialTab);
      }
    }
  }, [isOpen, initialTab, initialAppSettings]);

  if (!isOpen) return null;

  // Calculate doubles and triples in current selections
  let countDoubles = 0;
  let countTriples = 0;
  let totalSelections = 0;

  Object.values(currentSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      totalSelections++;
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  // Calculate pricing using settings rates
  const pricing = calculatePromosportPrice(
    countDoubles,
    countTriples,
    settings.columnRate,
    settings.baseFee
  );

  // Helper to translate team names
  const getTeamName = (teamName: string, frName?: string) => {
    if (lang === 'AR') {
      return ARABIC_TEAM_NAMES[teamName] || ARABIC_TEAM_NAMES[frName || ''] || teamName;
    }
    return frName || teamName;
  };

  // Toggle match choice
  const toggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isBettingLocked) {
      audioService.playClick();
      alert('تم قفل تعمير وتعديل القصاصات تلقائياً من بداية أول مقابلة حتى نهاية آخر المقابلات (يُفتح التعمير عند ظهور قصاصة جديدة).');
      return;
    }
    audioService.playClick();

    setCurrentSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];

      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
      } else {
        updated = [...current, sign];
      }

      return {
        ...prev,
        [matchId]: updated,
      };
    });
  };

  // Clear selections
  const handleClearSelections = () => {
    audioService.playClick();
    setCurrentSelections({});
    setEditingSlipId(null);
  };

  // Save current slip
  const handleSaveSlip = () => {
    if (isBettingLocked) {
      audioService.playClick();
      alert('تم قفل تسجيل وتعديل القصاصات تلقائياً عند بداية أول مقابلة حتى نهاية آخر المقابلات.');
      return;
    }
    if (totalSelections < 13) {
      alert(`الرجاء إكمال تعمير الـ 13 مباراة لحفظ القصاصة (المكتملة حالياً: ${totalSelections} / 13).`);
      return;
    }

    const nextSlipNumber = userSlips.length + 1;
    const newSlip: UserBetSlip = {
      id: editingSlipId || `slip-${Date.now()}`,
      grilleNumber: activeConcours.number,
      name: `قصاصة مسجلة رقم ${nextSlipNumber}`,
      createdAt: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) + ' ' + liveClock.slice(0, 5),
      updatedAt: liveClock,
      selections: currentSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      isLocked: isBettingLocked,
    };

    const updated = saveOrUpdateSlip(newSlip);
    setUserSlips(updated);
    audioService.playChime();

    confetti({
      particleCount: 50,
      spread: 70,
      colors: ['#f1b816', '#38bdf8', '#dc2626', '#ffffff'],
    });

    // Reset selections so that a new fresh empty slip is ready to be filled without marks
    setCurrentSelections({});
    setEditingSlipId(null);
    setActiveBottomNav('grille');
    setGrilleSubTab('mondiale');
    setSelectedFullSlip(null);

    setSlipNoticeMessage(`تم تسجيل القصاصة بنجاح! تم فتح تعمير قصاصة جديدة فارغة رقم ${updated.length + 1}`);
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 4000);
  };

  // Delete saved slip (immediately without blocking confirm dialog in iframe)
  const handleDeleteSlip = (slipId: string) => {
    audioService.playClick();
    const updated = deleteSlip(slipId);
    setUserSlips(updated);
    if (editingSlipId === slipId) {
      setEditingSlipId(null);
      setCurrentSelections({});
    }
    if (expandedSlipId === slipId) {
      setExpandedSlipId(updated.length > 0 ? updated[0].id : null);
    }
    setSlipNoticeMessage('تم فسخ القصاصة بنجاح من السجل!');
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 3000);
  };

  // Delete all saved slips
  const handleClearAllSlips = () => {
    audioService.playClick();
    const updated = clearAllSlips();
    setUserSlips(updated);
    setEditingSlipId(null);
    setCurrentSelections({});
    setExpandedSlipId(null);
    setSlipNoticeMessage('تم فسخ جميع القصاصات بنجاح من السجل!');
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 3000);
  };

  // Edit saved slip (only before first kickoff!)
  const handleEditSlip = (slip: UserBetSlip) => {
    if (isBettingLocked) {
      audioService.playClick();
      alert('لا يمكن تعديل أي قصاصة عند بداية أول مقابلة حتى نهاية آخر المقابلات (يُسمح بالفسخ فقط).');
      return;
    }
    audioService.playClick();
    setEditingSlipId(slip.id);
    setCurrentSelections(slip.selections);
    setActiveBottomNav('grille');
    setGrilleSubTab('mondiale');
  };

  // Save Settings handler
  const handleSaveAppSettings = () => {
    audioService.playClick();
    saveAppSettings(settings);
    if (onUpdateAppSettings) {
      onUpdateAppSettings(settings);
    }
    audioService.playChime();
    setSettingsSavedAlert(true);
    setTimeout(() => setSettingsSavedAlert(false), 3000);
  };

  // Reset Settings handler
  const handleResetAppSettings = () => {
    audioService.playClick();
    setSettings(DEFAULT_APP_SETTINGS);
    saveAppSettings(DEFAULT_APP_SETTINGS);
    if (onUpdateAppSettings) {
      onUpdateAppSettings(DEFAULT_APP_SETTINGS);
    }
  };

  // Render National Unavailable view with exact screenshot and refresh button
  const renderNationalUnavailableView = () => {
    return (
      <div className="flex flex-col items-center justify-center p-2 sm:p-4 text-center space-y-4 animate-fade-in max-w-lg mx-auto">
        {/* Exact official screenshot from user: Screenshot_20261103_235250_Chrome_4fcf597e.jpg */}
        <div className="relative group w-full max-w-[340px] sm:max-w-[360px] rounded-3xl overflow-hidden border-2 border-yellow-400/90 shadow-[0_0_35px_rgba(234,179,8,0.5)] bg-[#030918]">
          <img
            src="/assets/aistudio/Screenshot_20261103_235250_Chrome_4fcf597e.jpg"
            alt="Aucun match national dans ce tirage - Promosport Tunisie"
            className="w-full h-auto object-contain block select-none"
          />
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/30 via-transparent to-white/10" />
        </div>

        {/* Interactive "تحديث جديد" (Refresh) Button & Status */}
        <div className="w-full max-w-[360px] space-y-2.5">
          <button
            onClick={handleRefreshNational}
            disabled={isCheckingNational}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 hover:from-yellow-300 hover:to-amber-400 text-black font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(241,184,22,0.85)] active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-70 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isCheckingNational ? 'animate-spin' : ''}`} />
            <span>{isCheckingNational ? 'جارٍ فحص promosportplus.com...' : 'تحديث جديد وفحص المسابقة الوطنية'}</span>
          </button>

          {/* Live notification box */}
          <div className="p-3 rounded-2xl bg-black/75 border border-yellow-500/40 text-right text-[11px] text-gray-300 space-y-1.5 shadow-md">
            <div className="flex items-center justify-between text-yellow-300 font-bold">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                <span>حالة المسابقة الوطنية:</span>
              </span>
              <span className="font-mono text-[10px] text-cyan-300" dir="ltr">{lastNationalCheckTime}</span>
            </div>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              الموقع الرسمي <strong className="text-white">promosportplus.com</strong> أظهر سوى قصاصة عالمية واحدة فقط حالياً (المسابقة {liveConcours.number}). لا توجد مسابقة للبطولة الوطنية في هذا السحب.
            </p>
          </div>

          {/* Quick link button to switch to International Grille */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
              setGrilleSubTab('mondiale');
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-sky-950/70 hover:bg-sky-900/80 border border-sky-400/60 text-cyan-300 font-bold text-xs transition-colors flex items-center justify-center gap-2"
          >
            <span>الانتقال إلى القصاصة العالمية {liveConcours.number} المتاحة</span>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-2 bg-black/95 backdrop-blur-md animate-fade-in font-sans select-none"
    >
      {/* 3D Broadcast Stadium Shell Container - Fully responsive for all mobile screens */}
      <div
        onClickCapture={triggerGrilleIconFlash}
        className="relative flex flex-col bg-[#050e20] border-2 border-sky-400/80 shadow-[0_0_80px_rgba(56,189,248,0.5)] overflow-hidden transition-all duration-300 w-full max-w-2xl sm:max-w-3xl h-[100dvh] sm:h-[94vh] max-h-[100dvh] sm:rounded-3xl"
      >
        {/* Shimmering golden perimeter ray overlay around clicked icons */}
        {tapFlashes.map((flash) => (
          <span
            key={flash.id}
            aria-hidden="true"
            className="fixed z-[100] pointer-events-none grille-perimeter-ray border-2 border-yellow-200"
            style={{
              left: `${flash.left}px`,
              top: `${flash.top}px`,
              width: `${flash.width}px`,
              height: `${flash.height}px`,
              borderRadius: flash.radius,
              background: 'transparent',
              boxShadow:
                '0 0 20px 5px rgba(250,204,21,0.98), 0 0 38px 10px rgba(234,179,8,0.75), inset 0 0 8px rgba(254,240,138,0.6)',
            }}
          />
        ))}
        {/* CONDITIONAL: FULL SLIP PAGE VIEW OR REGULAR MODAL BODY */}
        {selectedFullSlip ? (
          <SavedSlipFullPageView
            slip={selectedFullSlip}
            concours={liveConcours}
            lang={lang}
            onBackToSlips={() => {
              setSelectedFullSlip(null);
              setActiveBottomNav('grille');
              setGrilleSubTab('slips');
            }}
            onBackToGrille={() => {
              setSelectedFullSlip(null);
              setActiveBottomNav('grille');
              setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
              setGrilleSubTab('mondiale');
            }}
            onUpdateSlip={(updatedSlip) => {
              const updated = saveOrUpdateSlip(updatedSlip);
              setUserSlips(updated);
              setSelectedFullSlip(updatedSlip);
            }}
            onDeleteSlip={(slipId) => {
              handleDeleteSlip(slipId);
              setSelectedFullSlip(null);
            }}
            getTeamName={getTeamName}
            isKickoffStarted={isBettingLocked}
            columnRate={settings.columnRate}
            baseFee={settings.baseFee}
          />
        ) : (
          <>
            {/* 1. TOP HEADER WITH MB LOGO (LEFT) & 50% SCALED GOLDEN BOX (RIGHT) */}
            <div className="shrink-0 px-3 sm:px-5 py-2.5 bg-gradient-to-r from-[#040a18] via-[#091a38] to-[#040a18] border-b border-yellow-500/50 flex items-center justify-between shadow-md">
              
              {/* MB LOGO + BACK TO MENU ICON BESIDE IT (وضع أيقونة رجوع إلى القائمة بجانب لوقو MB وتكبيرها 20%) */}
              <div className="flex items-center gap-2.5">
                <MbLogo size="md" showLaser={true} />
                <button
                  onClick={() => {
                    audioService.playClick();
                    onClose();
                  }}
                  title="رجوع إلى القائمة"
                  className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500/20 via-red-950/60 to-slate-900 border-2 border-yellow-400/80 text-yellow-200 hover:text-white hover:border-yellow-300 shadow-[0_0_14px_rgba(250,204,21,0.45)] active:scale-95 transition-all cursor-pointer flex items-center justify-center"
                >
                  <ArrowRight className="w-6 h-6" />
                </button>
              </div>

              {/* APP NAME, PHONE & INFO + 20% ENLARGED LANGUAGE TOGGLE ON RIGHT */}
              <div className="flex items-center gap-2.5">
                {/* 50% Scaled Golden Box */}
                <div className="px-2.5 py-1 rounded-xl bg-black/80 border border-yellow-400/70 shadow-[0_0_12px_rgba(241,184,22,0.4)] text-right">
                  <div className="text-[11px] font-black text-yellow-300 tracking-wide leading-tight">
                    {settings.appName} | {settings.phoneNumber}
                  </div>
                  <div className="text-[9px] text-gray-300 font-mono mt-0.5 flex items-center justify-end gap-1.5">
                    <span className="text-cyan-400 font-bold">V19.2 HD 3D</span>
                    <span>•</span>
                    <span className="text-yellow-400">قصاصة {settings.concoursNumber}</span>
                  </div>
                </div>

                {/* Language Toggle AR / FR (تكبير بنسبة 20%) */}
                <button
                  onClick={() => {
                    audioService.playClick();
                    setLang(lang === 'FR' ? 'AR' : 'FR');
                  }}
                  title="تعريب / تغيير اللغة"
                  className="px-3.5 py-2 rounded-xl bg-[#f1b816] text-black font-black text-base leading-none hover:bg-yellow-300 border-2 border-yellow-200 shadow-[0_0_14px_rgba(241,184,22,0.75)] active:scale-95 transition-all cursor-pointer"
                >
                  {lang}
                </button>
              </div>
            </div>

        {/* 4. MAIN BODY CONTAINER */}
        {activeBottomNav === 'grille' && grilleSubTab === 'mondiale' ? (
          /* GRILLE VIEW (خانة القصاصة): Exact Saved Slips chassis dimensions +10% & 3D cylindrical wheel without saved marks */
          <div className="flex-1 relative overflow-hidden flex flex-col">
            {/* Floating Transparent Glass Top Bar (يغلق أوتوماتيكياً عند التحريك ويفتح يدوياً) */}
            <div className="absolute top-0 inset-x-0 z-30 pointer-events-none w-full bg-transparent">
              <PromosportUnifiedBadge
                concours={liveConcours}
                cagnotte={liveConcours.cagnotteEstimate}
                lang={lang}
                isKickoffStarted={isBettingLocked}
                activeSubTab={grilleSubTab}
                isOpen={isGrilleRibbonOpen}
                onToggleOpen={setIsGrilleRibbonOpen}
                onSelectSubTab={(tab) => {
                  audioService.playClick();
                  if (tab === 'slips') {
                    setGrilleSubTab('slips');
                  } else if (tab === 'mondiale') {
                    setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
                    setGrilleSubTab('mondiale');
                  } else if (tab === 'nationale') {
                    setGrilleSubTab('nationale');
                  }
                }}
                slipsCount={userSlips.length}
                showTabs={true}
              />
            </div>

            {slipNoticeMessage && (
              <div className="absolute bottom-2 inset-x-3 z-30 p-2 rounded-xl bg-emerald-950/95 border border-emerald-400 text-emerald-200 font-bold text-xs flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-fade-in">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{slipNoticeMessage}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSlipNoticeMessage(null)}
                  className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <Grille3DWheelView
              matches={liveConcours.matches}
              lang={lang}
              isBettingLocked={isBettingLocked}
              selections={currentSelections}
              onToggleSelection={toggleSelection}
              getTeamName={getTeamName}
              onUserScrollMove={() => setIsGrilleRibbonOpen(false)}
              goalFlashMatchIds={goalFlashMatchIds}
            />
          </div>
        ) : (
        <div className="flex-1 overflow-y-auto relative overscroll-contain [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          
          {/* 2. UNIFIED PROMOSPORT CAGNOTTE & GRILLE BADGE */}
          {activeBottomNav !== 'apk' && (
            <div className="sticky top-0 z-30 pointer-events-none w-full bg-transparent">
              <PromosportUnifiedBadge
                concours={liveConcours}
                cagnotte={liveConcours.cagnotteEstimate}
                tirageGrille={activeBottomNav === 'tirage' ? activeTirage : null}
                onRefreshTirage={activeBottomNav === 'tirage' ? handleRefreshTirageFromSite : undefined}
                isRefreshingTirage={isRefreshingTirage}
                lang={lang}
                isKickoffStarted={isBettingLocked}
                activeSubTab={grilleSubTab}
                onSelectSubTab={(tab) => {
                  audioService.playClick();
                  if (tab === 'slips') {
                    setActiveBottomNav('grille');
                    setGrilleSubTab('slips');
                  } else if (tab === 'mondiale') {
                    setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
                    setGrilleSubTab('mondiale');
                  } else if (tab === 'nationale') {
                    setGrilleSubTab('nationale');
                  }
                }}
                slipsCount={userSlips.length}
                showTabs={activeBottomNav === 'grille'}
              />
            </div>
          )}

          <div className={`${activeBottomNav === 'grille' ? 'px-0 py-2' : 'p-2 sm:p-4'} space-y-2.5`}>

          {/* ========================================================= */}
          {/* TAB 2: GRILLE (القصاصة) - Interactive Betting or Saved Slips */}
          {/* ========================================================= */}
          {activeBottomNav === 'grille' && (
            <>
              {grilleSubTab === 'nationale' ? (
                renderNationalUnavailableView()
              ) : grilleSubTab === 'slips' ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between px-3 sm:px-4">
                    <h3 className="text-sm font-black text-yellow-400 flex items-center gap-2">
                      <FolderArchive className="w-4 h-4" />
                      <span>سجل القصاصات المسجلة ({userSlips.length})</span>
                    </h3>
                    {userSlips.length > 0 && (
                      <button
                        type="button"
                        onClick={handleClearAllSlips}
                        className="px-2.5 py-1 rounded-xl bg-red-950/70 hover:bg-red-800 border border-red-500/60 text-red-300 hover:text-white text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>فسخ جميع القصاصات</span>
                      </button>
                    )}
                  </div>

                  {slipNoticeMessage && (
                    <div className="p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 font-bold text-xs flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-fade-in">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{slipNoticeMessage}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSlipNoticeMessage(null)}
                        className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {userSlips.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-[#071328] border border-white/10 text-center space-y-3">
                      <div className="w-12 h-12 rounded-full bg-white/5 border border-white/20 mx-auto flex items-center justify-center text-gray-400">
                        <FolderArchive className="w-6 h-6" />
                      </div>
                      <p className="text-sm text-gray-300 font-bold">
                        لا توجد قصاصات مسجلة حالياً
                      </p>
                      <p className="text-xs text-gray-400">
                        قم بتعمير القصاصة العالمية أو الوطنية واضغط "تسجيل القصاصة" لحفظها هنا بالترتيب.
                      </p>
                      <button
                        onClick={() => setGrilleSubTab('mondiale')}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-black text-xs shadow-md"
                      >
                        تعمير قصاصة جديدة
                      </button>
                    </div>
                  ) : (
                    userSlips.map((slip, slipIndex) => {
                      const isExpanded = expandedSlipId === slip.id;

                      return (
                        <div
                          key={slip.id}
                          className="rounded-2xl bg-[#08152e] border-2 border-yellow-500/60 overflow-hidden shadow-lg"
                        >
                          {/* Slip Header - Clicking opens full page 13-match view */}
                          <div
                            onClick={() => {
                              audioService.playClick();
                              setSelectedFullSlip(slip);
                            }}
                            className="p-3 bg-gradient-to-r from-[#091a38] via-[#0c2450] to-[#091a38] flex items-center justify-between cursor-pointer hover:bg-sky-950/60 transition-colors group"
                          >
                            <div className="flex items-center gap-2.5">
                              <div className="w-7 h-7 rounded-xl bg-yellow-400 text-black font-black text-xs flex items-center justify-center shadow">
                                #{slipIndex + 1}
                              </div>
                              <div>
                                <h4 className="font-black text-xs sm:text-sm text-yellow-300">
                                  {slip.name}
                                </h4>
                                <div className="text-[10px] text-gray-400 flex items-center gap-2 mt-0.5">
                                  <span>بتاريخ: {slip.createdAt}</span>
                                  <span>•</span>
                                  <span className="text-cyan-400 font-mono">
                                    {slip.totalCombinations} عمود
                                  </span>
                                  <span>•</span>
                                  <span className="text-emerald-400 font-bold" dir="ltr">
                                    {slip.totalCostDt.toFixed(3)} TND
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              {!isBettingLocked && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleEditSlip(slip);
                                  }}
                                  title="تعديل القصاصة (متاح قبل بداية المباريات)"
                                  className="p-1.5 rounded-lg bg-sky-500/20 text-sky-300 hover:bg-sky-500 hover:text-black transition-colors"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                              )}

                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteSlip(slip.id);
                                }}
                                title="فسخ القصاصة نهائياً (متاح في أي وقت)"
                                className="px-2.5 py-1 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-500/60 text-red-200 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold shadow-md cursor-pointer active:scale-95"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>فسخ القصاصة</span>
                              </button>
                            </div>
                          </div>

                          {/* Expanded 13 Matches View with ✓ / ✗ */}
                          {isExpanded && (
                            <div className="px-0 py-2 bg-black/60 border-t border-white/10 space-y-1.5">
                              <div className="text-[11px] text-gray-300 font-bold px-3 pb-1 flex justify-between">
                                <span>المقابلات الـ 13 مع علامات الصح والخطأ والنتائج الرسمية:</span>
                                <span className="text-yellow-400">قصاصة مسابقة {slip.grilleNumber}</span>
                              </div>

                              {liveConcours.matches.map((m) => {
                                const userChoices = slip.selections[m.id] || [];
                                return (
                                  <BroadcastScoreboardMatch
                                    key={m.id}
                                    match={m}
                                    lang={lang}
                                    mode="slip"
                                    isKickoffStarted={isBettingLocked}
                                    slipChoices={userChoices}
                                    getTeamName={getTeamName}
                                  />
                                );
                              })}

                              {/* Footer Action: Delete Slip at any time */}
                              <div className="pt-2 flex items-center justify-between border-t border-white/10 px-3">
                                <span className="text-[10px] text-gray-400">
                                  يمكن فسخ أي قصاصة مسجلة في أي وقت
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteSlip(slip.id);
                                  }}
                                  className="px-3 py-1 rounded-xl bg-red-600/40 hover:bg-red-600 border border-red-500 text-red-200 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold shadow cursor-pointer active:scale-95"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>فسخ هذه القصاصة نهائياً</span>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              ) : null}
            </>
          )}

          {/* ========================================================= */}
          {/* TAB 3: TIRAGE (النتائج الرسمية لآخر 3 قصاصات سابقة مرتبة دون القصاصة النشطة) */}
          {/* ========================================================= */}
          {activeBottomNav === 'tirage' && activeTirage && (
            <div className="space-y-4">
              {/* Concours Switcher Tabs: ordered strictly descending excluding active concours (e.g. 933 / 932 / 931) */}
              <div className="flex items-center justify-center flex-wrap gap-2 px-2">
                {recentGrilles.map((g) => {
                  const isActive = g.number === activeTirage.number;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        audioService.playClick();
                        setSelectedTirageNumber(g.number);
                      }}
                      className={`px-4 py-2 rounded-xl font-black text-xs sm:text-sm transition-all cursor-pointer active:scale-95 ${
                        isActive
                          ? 'bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black border-2 border-white shadow-[0_0_18px_rgba(250,204,21,0.9)] scale-105'
                          : 'bg-[#091834] text-gray-200 hover:text-white border border-yellow-400/50 hover:border-yellow-300'
                      }`}
                    >
                      Tirage #{g.number}
                    </button>
                  );
                })}
              </div>

              {/* Official Draw Summary Header (القيمة المالية + عدد المرابيح + نصيب كل عمود) */}
              <div className="rounded-2xl bg-[#08152e]/90 border-2 border-yellow-400/80 p-3.5 shadow-[0_6px_22px_rgba(250,204,21,0.2)] space-y-2.5">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-yellow-300 to-amber-500 text-black font-black text-xs flex items-center justify-center shadow">
                      #{activeTirage.number}
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-yellow-300">
                        {lang === 'AR'
                          ? `المسابقة العالمية N° ${activeTirage.number}`
                          : `Concours International N° ${activeTirage.number}`}
                      </h4>
                      <span className="text-[11px] text-gray-300 font-mono" dir="ltr">
                        {activeTirage.date}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[11px] text-gray-400 block">القيمة المالية (الجائزة الكبرى):</span>
                    <span className="text-sm font-black font-mono text-emerald-400" dir="ltr">
                      {activeTirage.cagnotteFormatted}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs bg-black/50 p-2.5 rounded-xl border border-yellow-400/30 text-center">
                  <div>
                    <span className="text-gray-400 block text-[11px]">القيمة المالية:</span>
                    <span className="font-black text-emerald-300 font-mono" dir="ltr">
                      {activeTirage.cagnotteFormatted}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block text-[11px]">عدد المرابيح:</span>
                    <span className="font-black text-white">{activeTirage.winnersFormatted}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block text-[11px]">نصيب كل عمود:</span>
                    <span className="font-black text-yellow-300 font-mono" dir="ltr">
                      {activeTirage.prizePerWinnerFormatted}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-gray-400 px-1">
                  <span dir="ltr">promosportplus.com/grille_int_result.php</span>
                  <button
                    type="button"
                    onClick={handleRefreshTirageFromSite}
                    disabled={isRefreshingTirage}
                    className="flex items-center gap-1 text-yellow-300 hover:text-yellow-200 font-bold cursor-pointer disabled:opacity-60"
                  >
                    <RefreshCw className={`w-3 h-3 ${isRefreshingTirage ? 'animate-spin' : ''}`} />
                    <span>تحديث من الموقع الآن</span>
                  </button>
                </div>
              </div>

                {/* 13 Matches Rendered with Exact Pinterest Broadcast Scoreboard + Golden Translucent Glass Tray */}
                <div className="space-y-4">
                  {activeTirage.matches.map((m) => {
                    const parts = m.score.split(/[-:]/).map((s) => s.trim());
                    const adaptedMatch: WeeklyConcoursMatch = {
                      id: m.id,
                      homeTeam: m.homeTeam,
                      homeTeamFr: m.homeTeamFr,
                      homeLogo: m.homeLogo || 'CLUB',
                      awayTeam: m.awayTeam,
                      awayTeamFr: m.awayTeamFr,
                      awayLogo: m.awayLogo || 'CLUB',
                      date: activeTirage.date.split(' ')[0] || activeTirage.date,
                      time: activeTirage.date.split('à ')[1] || '15:00',
                      dayTime: activeTirage.date.split('à ')[1] || '15:00',
                      kickoffTimestamp: 0,
                      status: 'finished',
                      score: m.score,
                      scoreHome: parts[0] || '0',
                      scoreAway: parts[1] || '0',
                      competition: m.competition || `المسابقة العالمية #${activeTirage.number}`,
                      competitionFr: m.competitionFr || `CONCOURS INT #${activeTirage.number}`,
                      result: m.result,
                      prob1: 40,
                      probX: 30,
                      prob2: 30,
                    };

                    return (
                      <PinterestScoreboardCard
                        key={`${activeTirage.number}-${m.id}`}
                        match={adaptedMatch}
                        lang={lang}
                        mode="tirage"
                        getTeamName={getTeamName}
                      />
                    );
                  })}
                </div>
              </div>
            )}

          {/* ========================================================= */}
          {/* TAB 4: SETTINGS (صفحة الإعدادات الأصلية للتطبيق مع تعديلها) */}
          {/* ========================================================= */}
          {activeBottomNav === 'settings' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#0a1b38] via-[#0f2854] to-[#0a1b38] border border-yellow-500/50 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-yellow-400 text-black flex items-center justify-center">
                    <Settings className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-yellow-300">
                      صفحة الإعدادات الأصلية للتطبيق
                    </h3>
                    <p className="text-[11px] text-gray-300">
                      تعديل هوية التطبيق، معرف الحزمة، رقم الهاتف وضوابط القصاصات
                    </p>
                  </div>
                </div>

                {settingsSavedAlert && (
                  <span className="px-3 py-1 rounded-full bg-emerald-500 text-black font-black text-xs animate-bounce">
                    تم الحفظ بنجاح!
                  </span>
                )}
              </div>

              {/* Form Fields */}
              <div className="space-y-2.5">
                
                {/* 1. اسم التطبيق */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">اسم التطبيق</label>
                      <span className="text-[10px] text-gray-400">الاسم الظاهر في الواجهة وشريط المهام</span>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={settings.appName}
                    onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                    className="w-48 sm:w-60 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs text-white text-right focus:border-yellow-400 outline-none"
                  />
                </div>

                {/* 2. معرف الحزمة */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-yellow-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">معرف الحزمة (Package ID)</label>
                      <span className="text-[10px] text-gray-400">معرف أندرويد لتطبيق الـ APK</span>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={settings.packageId}
                    onChange={(e) => setSettings({ ...settings, packageId: e.target.value })}
                    className="w-48 sm:w-60 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono text-cyan-300 text-left focus:border-yellow-400 outline-none"
                    dir="ltr"
                  />
                </div>

                {/* 3. رقم الهاتف */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <PhoneCall className="w-4 h-4 text-emerald-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">رقم الهاتف</label>
                      <span className="text-[10px] text-gray-400">الرقم المذهب الظاهر في أعلى الواجهة</span>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={settings.phoneNumber}
                    onChange={(e) => setSettings({ ...settings, phoneNumber: e.target.value })}
                    className="w-48 sm:w-60 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-emerald-400 text-center focus:border-yellow-400 outline-none"
                    dir="ltr"
                  />
                </div>

                {/* 4. رقم القصاصة */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-amber-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">رقم القصاصة</label>
                      <span className="text-[10px] text-gray-400">ترقيم المسابقة الحالية (مثل {liveConcours.number})</span>
                    </div>
                  </div>
                  <input
                    type="number"
                    value={settings.concoursNumber}
                    onChange={(e) => setSettings({ ...settings, concoursNumber: Number(e.target.value) })}
                    className="w-24 sm:w-32 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-yellow-300 text-center focus:border-yellow-400 outline-none"
                  />
                </div>

                {/* 5. تسعيرة العمود */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Coins className="w-4 h-4 text-yellow-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">تسعيرة العمود (د.ت)</label>
                      <span className="text-[10px] text-gray-400">المعادلة الرسمية: 0.150 دينار للعمود</span>
                    </div>
                  </div>
                  <input
                    type="number"
                    step="0.010"
                    value={settings.columnRate}
                    onChange={(e) => setSettings({ ...settings, columnRate: parseFloat(e.target.value) || 0.150 })}
                    className="w-24 sm:w-32 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-cyan-300 text-center focus:border-yellow-400 outline-none"
                  />
                </div>

                {/* 6. معلوم القصاصة */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-pink-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">معلوم القصاصة (الطابع الجبائي د.ت)</label>
                      <span className="text-[10px] text-gray-400">المعلوم الثابت: 0.250 دينار لكل قصاصة</span>
                    </div>
                  </div>
                  <input
                    type="number"
                    step="0.010"
                    value={settings.baseFee}
                    onChange={(e) => setSettings({ ...settings, baseFee: parseFloat(e.target.value) || 0.250 })}
                    className="w-24 sm:w-32 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-pink-300 text-center focus:border-yellow-400 outline-none"
                  />
                </div>

                {/* 7. تفعيل سجل القصاصات */}
                <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckSquare className="w-4 h-4 text-emerald-400" />
                    <div>
                      <label className="text-xs font-bold text-gray-300 block">تفعيل سجل القصاصات</label>
                      <span className="text-[10px] text-gray-400">إظهار تبويب القصاصات المسجلة واسترجاعها</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setSettings({ ...settings, enableSlipsHistory: !settings.enableSlipsHistory })}
                    className={`px-3 py-1 rounded-xl text-xs font-black transition-all ${
                      settings.enableSlipsHistory
                        ? 'bg-emerald-500 text-black shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                        : 'bg-white/10 text-gray-400'
                    }`}
                  >
                    {settings.enableSlipsHistory ? 'مفعل ✓' : 'معطل ✗'}
                  </button>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  onClick={handleSaveAppSettings}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black font-black text-xs shadow-[0_0_15px_rgba(241,184,22,0.7)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  <span>حفظ وتطبيق الإعدادات</span>
                </button>

                <button
                  onClick={handleResetAppSettings}
                  className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 text-xs font-bold transition-all"
                >
                  استعادة الافتراضي
                </button>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 5: APK (مركز التفعيل والتثبيت وتنزيل التطبيق كاملاً) */}
          {/* ========================================================= */}
          {activeBottomNav === 'apk' && (
            <AppInstallPromptHub
              settings={settings}
              userSlips={userSlips}
              concours={liveConcours}
            />
          )}

          </div>
        </div>
        )}

        {/* 5. TICKET BETTING PRICING DOCK (ONLY ON GRILLE FILLING SUB-TAB) */}
        {activeBottomNav === 'grille' && grilleSubTab === 'mondiale' && (
          isBettingLocked ? (
            <div className="shrink-0 p-2 sm:p-3 bg-[#040c1a] border-t border-yellow-500/40 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs text-amber-300 font-bold">
                <Lock className="w-4 h-4 text-red-400 shrink-0" />
                <span>التعمير مقفل تلقائياً — عرض النتائج المباشرة حتى ظهور قصاصة جديدة</span>
              </div>
              <button
                onClick={() => setGrilleSubTab('slips')}
                className="px-4 py-2 rounded-xl bg-[#0e2142] hover:bg-[#142d59] border border-sky-400 text-sky-200 font-bold text-xs active:scale-95 transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
              >
                <FolderArchive className="w-3.5 h-3.5 text-yellow-400" />
                <span>القصاصات ({userSlips.length})</span>
              </button>
            </div>
          ) : (
          <div className="shrink-0 p-2 sm:p-3 bg-[#040c1a] border-t border-sky-400/50 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <span className="text-gray-300 font-bold">
                  المباريات: <strong className="text-cyan-300">{totalSelections}</strong> / 13
                </span>
                <span className="text-gray-300 font-bold">
                  ثنائيات: <strong className="text-yellow-400">{countDoubles}</strong>
                </span>
                <span className="text-gray-300 font-bold">
                  ثلاثيات: <strong className="text-yellow-400">{countTriples}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2 font-mono">
                <span className="text-gray-400 text-[11px]">الأعمدة: {pricing.combinations}</span>
                <span className="px-2 py-0.5 rounded-lg bg-yellow-400 text-black font-black text-xs" dir="ltr">
                  {pricing.formattedTnd}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleSaveSlip}
                disabled={isBettingLocked}
                className="py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 text-black font-black text-xs shadow-[0_0_12px_rgba(16,185,129,0.7)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:hover:scale-100 disabled:cursor-not-allowed"
              >
                <Save className="w-3.5 h-3.5" />
                <span>تسجيل القصاصة</span>
              </button>

              <button
                onClick={() => setGrilleSubTab('slips')}
                className="py-2 rounded-xl bg-[#0e2142] hover:bg-[#142d59] border border-sky-400 text-sky-200 font-bold text-xs active:scale-95 transition-all flex items-center justify-center gap-1"
              >
                <FolderArchive className="w-3.5 h-3.5 text-yellow-400" />
                <span>القصاصات ({userSlips.length})</span>
              </button>

              <button
                onClick={handleClearSelections}
                className="py-2 rounded-xl bg-[#e60067] hover:bg-pink-600 text-white font-black text-xs active:scale-95 transition-all flex items-center justify-center"
              >
                إلغاء التحديد
              </button>
            </div>
          </div>
          )
        )}

        {/* 6. BOTTOM 4-TABS NAVIGATION BAR (تم فسخ الخانة الرئيسية) */}
        <div className="shrink-0 px-2 py-2 bg-[#030814] border-t border-sky-500/40 grid grid-cols-4 gap-1 select-none z-30">

          {/* 1. القصاصة */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('grille');
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all shadow-[0_0_15px_rgba(241,184,22,0.6)] ${
              activeBottomNav === 'grille' ? 'bg-[#f1b816] text-black font-black' : 'text-gray-400 hover:text-yellow-400'
            }`}
          >
            <LayoutGrid className="w-4 h-4 mb-0.5 text-current" />
            <span className="text-[10px] font-black">القصاصة</span>
          </button>

          {/* 3. Tirage */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('tirage');
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
              activeBottomNav === 'tirage' ? 'bg-cyan-400 text-black font-black' : 'text-gray-400 hover:text-cyan-400'
            }`}
          >
            <Ticket className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">Tirage</span>
          </button>

          {/* 4. الإعدادات */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('settings');
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
              activeBottomNav === 'settings' ? 'bg-cyan-400 text-black font-black' : 'text-gray-400 hover:text-cyan-400'
            }`}
          >
            <Settings className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">الإعدادات</span>
          </button>

          {/* 5. برومبت APK */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('apk');
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
              activeBottomNav === 'apk' ? 'bg-cyan-400 text-black font-black' : 'text-gray-400 hover:text-cyan-400'
            }`}
          >
            <Smartphone className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">برومبت APK</span>
          </button>

        </div>
          </>
        )}

      </div>
    </div>
  );
};
