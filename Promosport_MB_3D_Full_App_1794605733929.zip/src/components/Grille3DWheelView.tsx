/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { WeeklyConcoursMatch } from '../types/promosport';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';

interface Grille3DWheelViewProps {
  matches: WeeklyConcoursMatch[];
  lang: 'AR' | 'FR';
  isBettingLocked: boolean;
  selections: Record<number, ('1' | 'X' | '2')[]>;
  onToggleSelection: (matchId: number, sign: '1' | 'X' | '2') => void;
  getTeamName: (teamName: string, frName?: string) => string;
  onUserScrollMove?: () => void;
  goalFlashMatchIds?: Record<number, number>;
}

export const Grille3DWheelView: React.FC<Grille3DWheelViewProps> = ({
  matches,
  lang,
  isBettingLocked,
  selections,
  onToggleSelection,
  getTeamName,
  onUserScrollMove,
  goalFlashMatchIds = {},
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [cardTransforms, setCardTransforms] = useState<
    Record<number, { rotateX: number; scale: number; opacity: number }>
  >({});
  const [spacers, setSpacers] = useState<{ top: number; bottom: number }>({
    top: 155,
    bottom: 140,
  });

  // Mouse drag-to-scroll support for desktop
  const isMouseDownRef = useRef<boolean>(false);
  const startYRef = useRef<number>(0);
  const scrollTopRef = useRef<number>(0);
  const lastScrollTopRef = useRef<number>(0);
  const onUserScrollMoveRef = useRef(onUserScrollMove);
  onUserScrollMoveRef.current = onUserScrollMove;

  // Measure container & first/last card heights so Match #1 clears top ribbon cleanly
  // and Match #13 centers cleanly at max scroll
  const updateSpacers = useCallback(() => {
    const container = scrollContainerRef.current;
    if (!container || matches.length === 0) return;

    const containerHeight = container.clientHeight;
    const firstEl = document.getElementById(`grille-wheel-match-${matches[0].id}`);
    const lastEl = document.getElementById(`grille-wheel-match-${matches[matches.length - 1].id}`);

    const firstHeight = firstEl ? firstEl.offsetHeight : 184;
    const lastHeight = lastEl ? lastEl.offsetHeight : 184;

    const top = Math.max(138, Math.round(containerHeight / 2 - firstHeight / 2));
    const bottom = Math.max(32, Math.round(containerHeight / 2 - lastHeight / 2));

    setSpacers((prev) => (prev.top === top && prev.bottom === bottom ? prev : { top, bottom }));
  }, [matches]);

  // Cylindrical 3D wheel curvature on scroll while keeping exact edge-to-edge width
  const update3DWheelEffect = useCallback(() => {
    if (!scrollContainerRef.current) return;
    const container = scrollContainerRef.current;
    const containerRect = container.getBoundingClientRect();
    const containerCenter = containerRect.top + containerRect.height / 2;
    const maxDistance = Math.max(1, containerRect.height / 2);

    const newTransforms: Record<number, { rotateX: number; scale: number; opacity: number }> = {};

    matches.forEach((match) => {
      const el = document.getElementById(`grille-wheel-match-${match.id}`);
      if (el) {
        const elRect = el.getBoundingClientRect();
        const elCenter = elRect.top + elRect.height / 2;
        const distFromCenter = elCenter - containerCenter;
        const normalized = Math.max(-1.2, Math.min(1.2, distFromCenter / maxDistance));

        const rotateX = normalized * -20;
        const scale = 1 - Math.abs(normalized) * 0.08;
        const opacity = 1 - Math.abs(normalized) * 0.15;

        newTransforms[match.id] = {
          rotateX,
          scale: Math.max(0.9, scale),
          opacity: Math.max(0.7, opacity),
        };
      }
    });

    setCardTransforms(newTransforms);
  }, [matches]);

  useEffect(() => {
    updateSpacers();
    update3DWheelEffect();
    const container = scrollContainerRef.current;
    if (container) {
      lastScrollTopRef.current = container.scrollTop;
    }

    const handleContainerScroll = () => {
      update3DWheelEffect();
      if (!scrollContainerRef.current) return;
      const currentTop = scrollContainerRef.current.scrollTop;
      if (Math.abs(currentTop - lastScrollTopRef.current) > 2) {
        lastScrollTopRef.current = currentTop;
        onUserScrollMoveRef.current?.();
      }
    };

    let resizeObserver: ResizeObserver | null = null;
    if (container) {
      container.addEventListener('scroll', handleContainerScroll, { passive: true });
      if (typeof ResizeObserver !== 'undefined') {
        resizeObserver = new ResizeObserver(() => {
          updateSpacers();
          update3DWheelEffect();
        });
        resizeObserver.observe(container);
      }
    }

    const handleResize = () => {
      updateSpacers();
      update3DWheelEffect();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      if (container) {
        container.removeEventListener('scroll', handleContainerScroll);
      }
      if (resizeObserver) {
        resizeObserver.disconnect();
      }
      window.removeEventListener('resize', handleResize);
    };
  }, [updateSpacers, update3DWheelEffect]);

  useEffect(() => {
    update3DWheelEffect();
  }, [spacers, update3DWheelEffect]);

  // Mouse drag-to-scroll handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollContainerRef.current) return;
    isMouseDownRef.current = true;
    startYRef.current = e.pageY - scrollContainerRef.current.offsetTop;
    scrollTopRef.current = scrollContainerRef.current.scrollTop;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !scrollContainerRef.current) return;
    e.preventDefault();
    const y = e.pageY - scrollContainerRef.current.offsetTop;
    const delta = y - startYRef.current;
    if (Math.abs(delta) > 4) {
      onUserScrollMoveRef.current?.();
    }
    const walk = delta * 1.5;
    scrollContainerRef.current.scrollTop = scrollTopRef.current - walk;
    update3DWheelEffect();
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
  };

  return (
    <div className="relative w-full h-full flex-1 flex flex-col select-none overflow-hidden">
      {/* 3D WHEEL CAROUSEL SCROLL CONTAINER */}
      <div
        ref={scrollContainerRef}
        onWheel={(e) => {
          if (Math.abs(e.deltaY) > 1) {
            onUserScrollMoveRef.current?.();
          }
        }}
        onTouchMove={() => {
          onUserScrollMoveRef.current?.();
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="flex-1 overflow-y-auto px-1 sm:px-2 py-2 space-y-5 overscroll-contain scroll-smooth cursor-grab active:cursor-grabbing [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
        style={{
          perspective: '1200px',
          perspectiveOrigin: '50% 50%',
        }}
      >
        {/* Top clearance spacer so Match #1 starts clear of floating glass header */}
        <div style={{ height: `${spacers.top}px` }} className="w-full shrink-0" aria-hidden="true" />

        {matches.map((match) => {
          const userChoices = selections[match.id] || [];
          const transform = cardTransforms[match.id] || { rotateX: 0, scale: 1, opacity: 1 };
          const justScoredGoal = Boolean(goalFlashMatchIds[match.id]);

          return (
            <div
              id={`grille-wheel-match-${match.id}`}
              key={match.id}
              className="relative w-full transition-transform duration-100 ease-out group my-3.5"
              dir="ltr"
              style={{
                transform: `rotateX(${transform.rotateX}deg) scale(${transform.scale})`,
                transformOrigin: '50% 50%',
                opacity: transform.opacity,
                transformStyle: 'preserve-3d',
              }}
            >
              <PinterestScoreboardCard
                match={match}
                lang={lang}
                mode="fill"
                isBettingLocked={isBettingLocked}
                selections={userChoices}
                onToggleSelection={onToggleSelection}
                getTeamName={getTeamName}
                justScoredGoal={justScoredGoal}
              />
            </div>
          );
        })}

        {/* Bottom spacer so Match #13 rises cleanly into center */}
        <div style={{ height: `${spacers.bottom}px` }} className="w-full shrink-0" aria-hidden="true" />
      </div>
    </div>
  );
};
