/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface MbLogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showLaser?: boolean;
  showArrows?: boolean;
}

export const MbLogo: React.FC<MbLogoProps> = ({
  size = 'md',
  className = '',
  showLaser = true,
  showArrows = true,
}) => {
  const dim = size === 'sm' ? 'w-10 h-10' : size === 'lg' ? 'w-20 h-20' : 'w-14 h-14';

  return (
    <div className={`relative flex items-center justify-center shrink-0 ${dim} ${className}`}>
      {/* Radiant Laser Aura encircling the shield (شعاع ليزري يشع حول الشعار) */}
      {showLaser && (
        <>
          <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-yellow-500/30 via-amber-300/40 to-yellow-600/30 blur-md animate-pulse pointer-events-none" />
          <div
            className="absolute -inset-1 rounded-full opacity-75 pointer-events-none animate-spin"
            style={{
              animationDuration: '6s',
              background:
                'conic-gradient(from 0deg, transparent 0deg, rgba(254, 240, 138, 0.9) 60deg, transparent 90deg, transparent 180deg, rgba(254, 240, 138, 0.9) 240deg, transparent 270deg)',
              filter: 'blur(2px)',
            }}
          />
        </>
      )}

      {/* TWO Golden Curved Arrows co-rotating in the SAME direction (السهمين يدوران من نفس الاتجاه مذهبة) */}
      {showArrows && (
        <div
          className="absolute inset-0 pointer-events-none animate-spin"
          style={{ animationDuration: '4s', animationTimingFunction: 'linear' }}
        >
          <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_8px_rgba(234,179,8,0.8)]">
            <defs>
              <linearGradient id="goldArrowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="50%" stopColor="#eab308" />
                <stop offset="100%" stopColor="#ca8a04" />
              </linearGradient>
              <marker id="arrowhead1" markerWidth="6" markerHeight="6" refX="4" refY="3" orient="auto">
                <polygon points="0 0, 6 3, 0 6" fill="url(#goldArrowGrad)" />
              </marker>
              <marker id="arrowhead2" markerWidth="6" markerHeight="6" refX="4" refY="3" orient="auto">
                <polygon points="0 0, 6 3, 0 6" fill="url(#goldArrowGrad)" />
              </marker>
            </defs>

            {/* Top Arrow arc rotating counter-clockwise/same direction */}
            <path
              d="M 82 40 A 42 42 0 0 0 45 10"
              fill="none"
              stroke="url(#goldArrowGrad)"
              strokeWidth="3.5"
              strokeLinecap="round"
              markerEnd="url(#arrowhead1)"
            />

            {/* Bottom Arrow arc rotating in the same flow */}
            <path
              d="M 18 60 A 42 42 0 0 0 55 90"
              fill="none"
              stroke="url(#goldArrowGrad)"
              strokeWidth="3.5"
              strokeLinecap="round"
              markerEnd="url(#arrowhead2)"
            />
          </svg>
        </div>
      )}

      {/* Central Golden Shield with Laurel Wreath and "MB" */}
      <div className="relative z-10 w-4/5 h-4/5 flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
          <defs>
            {/* Shield Golden Gradient */}
            <linearGradient id="shieldGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="35%" stopColor="#eab308" />
              <stop offset="70%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>

            {/* Inner Shield Dark Bronze Gradient */}
            <linearGradient id="innerShieldBg" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#451a03" />
              <stop offset="50%" stopColor="#1c1917" />
              <stop offset="100%" stopColor="#0c0a09" />
            </linearGradient>

            {/* Emblem Text Gold */}
            <linearGradient id="mbTextGold" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="30%" stopColor="#fef08a" />
              <stop offset="70%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
          </defs>

          {/* Outer Shield Rim */}
          <path
            d="M 15 18 Q 50 10 85 18 Q 85 55 50 90 Q 15 55 15 18 Z"
            fill="url(#shieldGold)"
            stroke="#fef08a"
            strokeWidth="2"
          />

          {/* Inner Shield Body */}
          <path
            d="M 20 22 Q 50 15 80 22 Q 80 52 50 84 Q 20 52 20 22 Z"
            fill="url(#innerShieldBg)"
            stroke="#b45309"
            strokeWidth="1.5"
          />

          {/* Golden Laurel Wreath Leaves (إكليل الغار المذهب) */}
          {/* Left Laurel Branch */}
          <path
            d="M 50 74 C 34 68 26 48 28 32 C 30 26 34 24 35 27 C 33 34 35 52 48 64 Z"
            fill="url(#shieldGold)"
            opacity="0.9"
          />
          {/* Right Laurel Branch */}
          <path
            d="M 50 74 C 66 68 74 48 72 32 C 70 26 66 24 65 27 C 67 34 65 52 52 64 Z"
            fill="url(#shieldGold)"
            opacity="0.9"
          />

          {/* Laurel Leaf Details */}
          {[
            { cx: 32, cy: 35, r: 2.5 },
            { cx: 30, cy: 43, r: 2.8 },
            { cx: 32, cy: 52, r: 3 },
            { cx: 36, cy: 60, r: 3.2 },
            { cx: 43, cy: 67, r: 3 },
            { cx: 68, cy: 35, r: 2.5 },
            { cx: 70, cy: 43, r: 2.8 },
            { cx: 68, cy: 52, r: 3 },
            { cx: 64, cy: 60, r: 3.2 },
            { cx: 57, cy: 67, r: 3 },
          ].map((leaf, i) => (
            <circle key={i} cx={leaf.cx} cy={leaf.cy} r={leaf.r} fill="#fde047" opacity="0.95" />
          ))}

          {/* Central Bold "MB" Lettering */}
          <text
            x="50"
            y="54"
            fill="url(#mbTextGold)"
            fontSize="30"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            letterSpacing="-1"
            filter="drop-shadow(0 2px 4px rgba(0,0,0,0.9))"
          >
            MB
          </text>
        </svg>
      </div>
    </div>
  );
};
