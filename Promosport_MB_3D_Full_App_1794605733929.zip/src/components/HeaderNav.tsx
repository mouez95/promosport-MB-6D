/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bell } from 'lucide-react';
import { audioService } from '../services/audioService';
import { MbLogo } from './MbLogo';
import { AppSettings } from '../types/promosport';

interface HeaderNavProps {
  onOpenNotifications: () => void;
  hasUnreadAlerts: boolean;
  lastUpdated: string;
  appSettings?: AppSettings;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  onOpenNotifications,
  hasUnreadAlerts,
  lastUpdated,
  appSettings,
}) => {
  return (
    <header className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-4 sm:px-8 py-3 pointer-events-none">
      {/* Top Right (in RTL): Notification Bell + subtle sync indicator */}
      <div className="flex items-center gap-3 pointer-events-auto">
        <button
          onClick={() => {
            audioService.playClick();
            onOpenNotifications();
          }}
          title="منظومة التنبيهات والتحديث التلقائي"
          className="relative group p-3 rounded-2xl bg-black/60 border border-yellow-500/40 hover:border-yellow-400 hover:bg-black/80 transition-all duration-300 shadow-[0_0_15px_rgba(234,179,8,0.25)] hover:shadow-[0_0_25px_rgba(234,179,8,0.6)] active:scale-95 cursor-pointer"
        >
          <Bell className="w-6 h-6 text-yellow-400 group-hover:text-yellow-300 transition-transform duration-300 group-hover:rotate-12" />
          {hasUnreadAlerts && (
            <span className="absolute top-2 right-2 w-3 h-3 bg-red-600 rounded-full border-2 border-black animate-ping" />
          )}
          {hasUnreadAlerts && (
            <span className="absolute top-2 right-2 w-3 h-3 bg-red-600 rounded-full border-2 border-black" />
          )}
        </button>

        <div className="hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/60 border border-emerald-500/30 text-xs font-medium text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>مباشر: promosportplus.com</span>
          <span className="text-gray-400 text-[11px] mr-1" dir="ltr">{lastUpdated}</span>
        </div>
      </div>

      {/* Top Left (in RTL): Promosport Tunisia Icon on the left, without axis & with transparent background */}
      <div className="pointer-events-auto flex items-center gap-2 bg-transparent border-0 shadow-none p-0">
        <div className="flex flex-col text-left leading-tight bg-transparent">
          <span className="text-yellow-400 font-black text-xs sm:text-sm tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)]">
            {appSettings?.appName || 'بروموسبور تونس'}
          </span>
          <span className="text-emerald-400 font-black text-[11px] tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)]" dir="ltr">
            {appSettings?.phoneNumber || '51155580'}
          </span>
        </div>
        <MbLogo size="sm" showLaser={false} showArrows={false} />
      </div>
    </header>
  );
};
