/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { audioService } from '../services/audioService';

interface GoldenEmblemProps {
  onOpenGrille?: () => void;
  onInteract?: (message: string) => void;
}

export const GoldenEmblem: React.FC<GoldenEmblemProps> = ({ onOpenGrille, onInteract }) => {
  const [ripples, setRipples] = useState<{ id: number }[]>([]);
  const [isSparkling, setIsSparkling] = useState(false);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Audio chime
    audioService.playGoldenRipple();

    // Trigger radiant shockwaves around the emblem
    const newRipple = { id: Date.now() };
    setRipples((prev) => [...prev, newRipple]);

    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== newRipple.id));
    }, 1200);

    // Sparkle effect
    setIsSparkling(true);
    setTimeout(() => setIsSparkling(false), 800);

    // Confetti particles in Tunisian gold & crimson colors
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    confetti({
      particleCount: 50,
      spread: 75,
      origin: { x, y },
      colors: ['#eab308', '#dc2626', '#fef08a', '#ffffff'],
      disableForReducedMotion: true,
    });

    if (onOpenGrille) {
      onOpenGrille();
    } else if (onInteract) {
      onInteract('بروموسبور تونس: حظ سعيد وموفق لكافة المتسابقين في المسابقة القادمة!');
    }
  };

  return (
    <div className="relative flex items-center justify-center">
      {/* 50% Enlarged Revolving Shining Light Ray Beam (شعاع لماع يدور حوله) */}
      <div className="absolute -inset-6 sm:-inset-8 pointer-events-none flex items-center justify-center animate-spin-beam">
        {/* Conic light beam ray sweeping 360 degrees */}
        <div
          className="w-full h-full rounded-full opacity-80"
          style={{
            background:
              'conic-gradient(from 0deg, transparent 0deg, transparent 60deg, rgba(254, 240, 138, 0.9) 85deg, rgba(234, 179, 8, 1) 90deg, rgba(254, 240, 138, 0.9) 95deg, transparent 120deg, transparent 240deg, rgba(254, 240, 138, 0.6) 265deg, rgba(234, 179, 8, 0.8) 270deg, rgba(254, 240, 138, 0.6) 275deg, transparent 300deg, transparent 360deg)',
            filter: 'blur(3px)',
          }}
        />
        {/* Bright optical flare tip on the ray */}
        <div className="absolute top-0 w-3 h-10 bg-yellow-200 rounded-full blur-[2px] shadow-[0_0_20px_#fef08a]" />
        <div className="absolute bottom-0 w-2.5 h-8 bg-yellow-300 rounded-full blur-[2px] shadow-[0_0_15px_#eab308]" />
      </div>

      {/* Expanding luminous ripple shockwaves upon interaction */}
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          className="absolute inset-0 rounded-full border-2 border-yellow-400/90 bg-yellow-400/15 ripple-effect pointer-events-none"
        />
      ))}

      {/* Radiant ambient glow aura */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-yellow-500/50 via-amber-300/40 to-yellow-600/50 blur-xl animate-gold-pulse pointer-events-none" />

      {/* Interactive Golden Emblem Button - Enlarged by 50% as requested (w-20 h-20 sm:w-22 sm:h-22) */}
      <button
        onClick={handleClick}
        title="فتح خانة القصاصة مباشرة"
        className={`relative z-10 w-20 h-20 sm:w-22 sm:h-22 rounded-full p-1 bg-gradient-to-br from-yellow-100 via-amber-400 to-yellow-700 shadow-[0_0_35px_rgba(234,179,8,0.85)] hover:shadow-[0_0_55px_rgba(234,179,8,1)] transition-all duration-300 hover:scale-110 active:scale-95 group focus:outline-none cursor-pointer ${
          isSparkling ? 'scale-125' : ''
        }`}
      >
        <div className="w-full h-full rounded-full bg-gradient-to-br from-stone-900 via-black to-stone-900 flex items-center justify-center border-2 border-yellow-300/80 overflow-hidden shadow-inner">
          {/* Stylized Promosport Golden Medallion SVG */}
          <svg
            viewBox="0 0 100 100"
            className="w-14 h-14 sm:w-16 sm:h-16 transition-transform duration-700 group-hover:rotate-180"
          >
            {/* Outer golden gear / sunburst ring */}
            <circle cx="50" cy="50" r="45" stroke="#eab308" strokeWidth="3" fill="none" opacity="0.85" />
            <circle cx="50" cy="50" r="40" stroke="#fef08a" strokeWidth="1.8" strokeDasharray="4 3" fill="none" />

            {/* Arabic Calligraphy text ribbon representation: النهوض بالرياضة */}
            <path
              d="M 24 28 Q 50 16 76 28"
              stroke="#fef08a"
              strokeWidth="2"
              fill="none"
              strokeLinecap="round"
            />

            {/* Central Promosport triple balls 1, X, 2 in gold & red */}
            {/* Ball 1 (Top Red) */}
            <circle cx="50" cy="38" r="16" fill="#dc2626" stroke="#fde047" strokeWidth="2.5" />
            <text x="50" y="44" fill="#ffffff" fontSize="16" fontWeight="900" textAnchor="middle">1</text>

            {/* Ball 2 (Left Black) */}
            <circle cx="34" cy="67" r="15" fill="#000000" stroke="#fde047" strokeWidth="2.5" />
            <text x="34" y="73" fill="#fde047" fontSize="15" fontWeight="900" textAnchor="middle">2</text>

            {/* Ball X (Right Amber) */}
            <circle cx="66" cy="67" r="15" fill="#ca8a04" stroke="#fde047" strokeWidth="2.5" />
            <text x="66" y="73" fill="#ffffff" fontSize="15" fontWeight="900" textAnchor="middle">X</text>
          </svg>
        </div>
      </button>
    </div>
  );
};
