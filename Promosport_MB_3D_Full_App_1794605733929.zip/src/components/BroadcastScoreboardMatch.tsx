/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { WeeklyConcoursMatch } from '../types/promosport';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';

interface BroadcastScoreboardMatchProps {
  match: WeeklyConcoursMatch;
  lang: 'AR' | 'FR';
  mode: 'home' | 'fill' | 'slip';
  isKickoffStarted?: boolean;
  selections?: ('1' | 'X' | '2')[];
  onToggleSelection?: (matchId: number, sign: '1' | 'X' | '2') => void;
  slipChoices?: ('1' | 'X' | '2')[];
  getTeamName: (teamName: string, frName?: string) => string;
}

export const BroadcastScoreboardMatch: React.FC<BroadcastScoreboardMatchProps> = ({
  match,
  lang,
  mode,
  isKickoffStarted = false,
  selections = [],
  onToggleSelection,
  slipChoices = [],
  getTeamName,
}) => {
  return (
    <div className={mode === 'home' ? 'my-1' : 'my-2'}>
      <PinterestScoreboardCard
        match={match}
        lang={lang}
        mode={mode}
        isBettingLocked={isKickoffStarted}
        selections={selections}
        onToggleSelection={onToggleSelection}
        slipChoices={slipChoices}
        getTeamName={getTeamName}
      />
    </div>
  );
};
