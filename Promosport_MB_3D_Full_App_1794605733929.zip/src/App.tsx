/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ThreeSoccerScene } from './components/ThreeSoccerScene';
import { HeaderNav } from './components/HeaderNav';
import { ControlDock } from './components/ControlDock';
import { NotificationModal } from './components/NotificationModal';
import { GrilleDetailModal } from './components/GrilleDetailModal';
import { ToastNotification } from './components/ToastNotification';
import { GoldenEmblem } from './components/GoldenEmblem';
import { WeeklyConcoursModal } from './components/WeeklyConcoursModal';
import { PWAInstallButton, OfflineIndicator } from './components/PWAInstallControls';
import { PromosportGrille, NotificationSettings, ToastAlert, WeeklyConcours, AppSettings } from './types/promosport';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  fetchPromosportSyncState,
  getOrderedRecentTirageGrilles,
  archiveConcoursToGrille,
} from './services/promosportData';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './services/matchLiveService';
import { loadSettings, saveSettings, loadAppSettings, saveAppSettings } from './services/storageService';
import { audioService } from './services/audioService';

export default function App() {
  const [grilles, setGrilles] = useState<PromosportGrille[]>(INITIAL_GRILLES);
  const [selectedGrille, setSelectedGrille] = useState<PromosportGrille | null>(null);
  const [targetGrilleNumber, setTargetGrilleNumber] = useState<number | null>(null);
  const [rotationSpeed, setRotationSpeed] = useState<number>(1);
  const [lastUpdated, setLastUpdated] = useState<string>('الآن');

  // App Settings state (editable App Name, Package ID, Phone, Rates)
  const [appSettings, setAppSettings] = useState<AppSettings>(() => loadAppSettings());

  // Weekly concours & bet slip manager state (Active: Concours 934)
  const [weeklyConcours, setWeeklyConcours] = useState<WeeklyConcours>(INITIAL_WEEKLY_CONCOURS);
  const [isWeeklyConcoursOpen, setIsWeeklyConcoursOpen] = useState<boolean>(false);
  const [weeklyConcoursTab, setWeeklyConcoursTab] = useState<'grille' | 'tirage' | 'settings' | 'apk'>('grille');

  const [settings, setSettings] = useState<NotificationSettings>(() => loadSettings());
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [currentAlert, setCurrentAlert] = useState<ToastAlert | null>(null);
  const [hasUnreadAlerts, setHasUnreadAlerts] = useState<boolean>(false);

  const prevLiveSnapshotRef = useRef<Record<number, { status: string; home: string; away: string }> | null>(null);
  const activeConcoursRef = useRef<WeeklyConcours>(weeklyConcours);
  activeConcoursRef.current = weeklyConcours;

  // Strictly ordered latest 3 previous grilles in Tirage (always excluding activeConcours.number) -> [933, 932, 931]
  const tirageGrilles = useMemo(
    () => getOrderedRecentTirageGrilles(grilles, weeklyConcours.number),
    [grilles, weeklyConcours.number]
  );

  // Helper to dispatch system push notification when enabled
  const emitPushIfEnabled = useCallback(
    (title: string, body: string) => {
      if (
        settings.pushNotificationsEnabled &&
        typeof window !== 'undefined' &&
        'Notification' in window &&
        Notification.permission === 'granted'
      ) {
        try {
          new Notification(title, { body });
        } catch {
          // ignore notification quota errors
        }
      }
    },
    [settings.pushNotificationsEnabled]
  );

  // Sync audio service with settings
  useEffect(() => {
    audioService.setSoundEnabled(settings.soundEnabled);
  }, [settings.soundEnabled]);

  // Synchronizes active concours & Tirage archive from /api/promosport/sync with silent rollover
  const syncFromServer = useCallback(
    async (isAuto = false, force = false) => {
      const payload = await fetchPromosportSyncState(force);
      const nowMs = Date.now();
      const timeStr = new Date(nowMs).toLocaleTimeString('ar-TN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setLastUpdated(timeStr);

      const currentConcours = activeConcoursRef.current;
      let nextConcours = payload.activeConcours;

      // Silent auto-rollover: if server provides a newer concours, adopt it silently and archive finished one
      const didRollover = nextConcours.number > currentConcours.number;
      if (nextConcours.number < currentConcours.number) {
        nextConcours = currentConcours;
      }

      const archivedList = [...payload.grilles];
      if (isConcoursCompletelyFinished(currentConcours, nowMs)) {
        const existing = archivedList.find((g) => g.number === currentConcours.number);
        const archivedCurrent = archiveConcoursToGrille(currentConcours, existing);
        if (!archivedList.some((g) => g.number === archivedCurrent.number)) {
          archivedList.unshift(archivedCurrent);
        }
      }

      setGrilles(archivedList);

      if (didRollover || nextConcours.number === currentConcours.number) {
        setWeeklyConcours(nextConcours);
      }

      if (didRollover) {
        setAppSettings((prev) => {
          if (prev.concoursNumber === nextConcours.number) return prev;
          const updatedSettings = { ...prev, concoursNumber: nextConcours.number };
          saveAppSettings(updatedSettings);
          return updatedSettings;
        });
        prevLiveSnapshotRef.current = null;
      }

      if (isAuto && (settings.notifyNewGrille || settings.notifyOfficialResults)) {
        const title = settings.notifyNewGrille
          ? `فحص التحديث التلقائي: القصاصة رقم ${nextConcours.number} جاهزة`
          : 'تحيين دوري ناجح';
        const message = `تحديث دوري (كل ${settings.checkIntervalMinutes} دقيقة) — القصاصة ${nextConcours.number} (${nextConcours.cagnotteEstimate}) متزامنة مع promosportplus.com.`;
        setCurrentAlert({
          id: `sync-${Date.now()}`,
          title,
          message,
          type: settings.notifyNewGrille ? 'grille' : 'result',
          timestamp: timeStr,
        });
        setHasUnreadAlerts(true);
        if (settings.soundEnabled) {
          audioService.playChime();
        }
        emitPushIfEnabled(title, message);
      }
    },
    [
      settings.notifyNewGrille,
      settings.notifyOfficialResults,
      settings.checkIntervalMinutes,
      settings.soundEnabled,
      emitPushIfEnabled,
    ]
  );

  // Initial silent sync with server on mount
  useEffect(() => {
    void syncFromServer(false, true);
  }, []);

  // ALWAYS ACTIVE: Continuous 1-second real-time live score, clock & completion rollover monitor
  useEffect(() => {
    let secondCounter = 0;

    const syncEverySecond = () => {
      const now = Date.now();
      const current = activeConcoursRef.current;
      const evaluated = evaluateConcoursRealTime(current, now);
      const timeStr = new Date(now).toLocaleTimeString('ar-TN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setLastUpdated(timeStr);

      const nextSnapshot: Record<number, { status: string; home: string; away: string }> = {};
      evaluated.matches.forEach((m) => {
        nextSnapshot[m.id] = {
          status: m.status,
          home: m.scoreHome ?? '0',
          away: m.scoreAway ?? '0',
        };
      });

      const prevSnapshot = prevLiveSnapshotRef.current;
      if (prevSnapshot) {
        for (const m of evaluated.matches) {
          const prev = prevSnapshot[m.id];
          if (!prev) continue;

          const curHome = m.scoreHome ?? '0';
          const curAway = m.scoreAway ?? '0';

          // 1. Live Goal Scored Event
          if (
            m.status === 'live' &&
            prev.status === 'live' &&
            (Number(curHome) > Number(prev.home) || Number(curAway) > Number(prev.away))
          ) {
            const title = `هدف مسجل الآن! (${m.homeTeam} ${curHome} - ${curAway} ${m.awayTeam})`;
            const message = `تحديث فوري مباشر • الدقيقة ${m.liveMinute || "1'"} — القصاصة رقم ${evaluated.number}`;
            setCurrentAlert({
              id: `goal-${m.id}-${Date.now()}`,
              title,
              message,
              type: 'golden',
              timestamp: timeStr,
            });
            setHasUnreadAlerts(true);
            if (settings.soundEnabled) audioService.playChime();
            emitPushIfEnabled(title, message);
          }
          // 2. Kickoff Started Event
          else if (prev.status === 'scheduled' && m.status === 'live') {
            const title = `انطلاق المقابلة #${m.id}: ${m.homeTeam} ضد ${m.awayTeam}`;
            const message = 'بدأت المقابلة الآن (0 - 0) مع التحديث المباشر كل ثانية.';
            setCurrentAlert({
              id: `kickoff-${m.id}-${Date.now()}`,
              title,
              message,
              type: 'result',
              timestamp: timeStr,
            });
            setHasUnreadAlerts(true);
            if (settings.soundEnabled) audioService.playWhistle();
            emitPushIfEnabled(title, message);
          }
          // 3. Match Full-Time Event
          else if (prev.status !== 'finished' && m.status === 'finished') {
            const title = `نهاية المقابلة #${m.id}: ${m.homeTeam} ${curHome} - ${curAway} ${m.awayTeam}`;
            const message = `النتيجة النهائية: ${m.result || '-'} • مسابقة رقم ${evaluated.number}`;
            if (settings.notifyOfficialResults) {
              setCurrentAlert({
                id: `ft-${m.id}-${Date.now()}`,
                title,
                message,
                type: 'result',
                timestamp: timeStr,
              });
              setHasUnreadAlerts(true);
              if (settings.soundEnabled) audioService.playChime();
              emitPushIfEnabled(title, message);
            }
          }
        }
      }

      prevLiveSnapshotRef.current = nextSnapshot;

      // Also silently check server every 30 seconds for live official updates or new grilles
      secondCounter += 1;
      if (secondCounter % 30 === 0) {
        void syncFromServer(false, false);
      }
    };

    syncEverySecond();
    const tickId = setInterval(syncEverySecond, 1000);
    return () => clearInterval(tickId);
  }, [settings.soundEnabled, settings.notifyOfficialResults, emitPushIfEnabled, syncFromServer]);

  // Initial welcome notification
  useEffect(() => {
    const timer = setTimeout(() => {
      const welcome: ToastAlert = {
        id: 'welcome-alert',
        title: 'بروموسبور تونس: جاهزية البث المباشر',
        message: 'تم تفعيل القصاصة الجديدة 934 والتحديث المستمر كل ثانية مع الخادم.',
        type: 'system',
        timestamp: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
      };
      setCurrentAlert(welcome);
      if (settings.soundEnabled) {
        audioService.playChime();
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  // Periodic automated sync check for new concours based on checkIntervalMinutes (15 / 30 / 60 min)
  useEffect(() => {
    if (!settings.autoUpdateActive) return;

    const intervalMs = settings.checkIntervalMinutes * 60 * 1000;
    const intervalId = setInterval(() => {
      void syncFromServer(true, true);
    }, intervalMs);

    return () => clearInterval(intervalId);
  }, [settings.autoUpdateActive, settings.checkIntervalMinutes, syncFromServer]);

  const handleSaveSettings = (newSettings: NotificationSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    audioService.setSoundEnabled(newSettings.soundEnabled);

    setCurrentAlert({
      id: `saved-${Date.now()}`,
      title: 'تم حفظ وتفعيل منظومة التحديثات بنجاح',
      message: `${
        newSettings.autoUpdateActive
          ? `فحص القصاصات الجديدة كل ${newSettings.checkIntervalMinutes} دقيقة`
          : 'التحديث التلقائي للقصاصات متوقف'
      } • التحديث المباشر كل ثانية مفعل دوماً.`,
      type: 'system',
      timestamp: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
    });
  };

  const handleTriggerTestAlert = () => {
    audioService.playChime();
    const testAlert: ToastAlert = {
      id: `test-${Date.now()}`,
      title: `إشعار قصاصة جديدة: المسابقة ${weeklyConcours.number} (${weeklyConcours.cagnotteEstimate})`,
      message: 'تم رصد القصاصة وتفعيل التحديث المستمر للنتائج والأهداف كل ثانية في الصفحة الرئيسية.',
      type: 'cagnotte',
      timestamp: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
    };
    setCurrentAlert(testAlert);
    setHasUnreadAlerts(true);
  };

  return (
    <div className="relative w-screen h-[100dvh] overflow-hidden bg-black select-none">
      {/* 3D Soccer Ball & Starry Universe Scene (Always shows latest 3 Tirage grilles: 933, 932, 931) */}
      <ThreeSoccerScene
        grilles={tirageGrilles}
        onSelectGrille={(grille) => {
          audioService.playWhistle();
          setSelectedGrille(grille);
        }}
        rotationSpeedMultiplier={rotationSpeed}
        targetGrilleNumber={targetGrilleNumber}
        onClearTargetGrille={() => setTargetGrilleNumber(null)}
      />

      {/* Top Header Navigation: Notification Bell + Promosport MB Badge */}
      <HeaderNav
        onOpenNotifications={() => {
          setHasUnreadAlerts(false);
          setIsNotificationsOpen(true);
        }}
        hasUnreadAlerts={hasUnreadAlerts}
        lastUpdated={lastUpdated}
        appSettings={appSettings}
      />

      {/* Toast Alert Notification respecting user-configured duration */}
      <ToastNotification
        alert={currentAlert}
        onDismiss={() => setCurrentAlert(null)}
        durationSeconds={settings.durationSeconds}
      />

      {/* 50% Enlarged Golden Promosport Emblem in bottom center - opens خانة القصاصة directly */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-20 pointer-events-auto">
        <GoldenEmblem
          onOpenGrille={() => {
            setWeeklyConcoursTab('grille');
            setIsWeeklyConcoursOpen(true);
          }}
        />
      </div>

      {/* Bottom Sleek Collapsible Control Dock on bottom right */}
      <ControlDock
        rotationSpeed={rotationSpeed}
        onChangeRotationSpeed={setRotationSpeed}
        onResetView={() => {
          setTargetGrilleNumber(null);
          setRotationSpeed(1);
        }}
        onFocusGrille={(num) => {
          audioService.playClick();
          setTargetGrilleNumber(num);
        }}
        activeGrilleNumber={targetGrilleNumber}
        activeConcoursNumber={weeklyConcours.number}
        recentGrilleNumbers={tirageGrilles.map((g) => g.number)}
        onOpenWeeklyConcours={() => {
          audioService.playClick();
          setWeeklyConcoursTab('grille');
          setIsWeeklyConcoursOpen(true);
        }}
      />

      {/* Weekly Concours & Interactive Bet Slip Manager Modal (القصاصة + Tirage) */}
      <WeeklyConcoursModal
        isOpen={isWeeklyConcoursOpen}
        onClose={() => setIsWeeklyConcoursOpen(false)}
        concours={weeklyConcours}
        onUpdateConcours={setWeeklyConcours}
        grilles={grilles}
        onRefreshSync={() => syncFromServer(false, true)}
        initialTab={weeklyConcoursTab}
        appSettings={appSettings}
        onUpdateAppSettings={(updated) => {
          setAppSettings(updated);
          saveAppSettings(updated);
        }}
      />

      {/* Advanced Notification System Modal */}
      <NotificationModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onTriggerTestAlert={handleTriggerTestAlert}
      />

      {/* Detailed Grille / Competition Modal (13 Match Results Table, LTR numbers) */}
      <GrilleDetailModal
        grille={selectedGrille}
        onClose={() => setSelectedGrille(null)}
      />

      {/* PWA Install Prompt & Offline Indicator */}
      <PWAInstallButton
        onOpenInstallHub={() => {
          setWeeklyConcoursTab('apk');
          setIsWeeklyConcoursOpen(true);
        }}
      />
      <OfflineIndicator />
    </div>
  );
}
