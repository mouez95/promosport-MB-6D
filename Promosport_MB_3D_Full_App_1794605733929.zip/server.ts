/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'node:path';
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  archiveConcoursToGrille,
} from './src/services/promosportData.ts';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './src/services/matchLiveService.ts';
import type { PromosportGrille, WeeklyConcours } from './src/types/promosport.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

interface ServerSyncCache {
  activeConcours: WeeklyConcours;
  grilles: PromosportGrille[];
  syncedAt: string;
  lastAttemptMs: number;
  lastRemoteSuccessMs: number;
}

const syncCache: ServerSyncCache = {
  activeConcours: INITIAL_WEEKLY_CONCOURS,
  grilles: [...INITIAL_GRILLES],
  syncedAt: new Date().toISOString(),
  lastAttemptMs: 0,
  lastRemoteSuccessMs: 0,
};

function mergeGrilleList(base: PromosportGrille[], extra: PromosportGrille[]): PromosportGrille[] {
  const byNumber = new Map<number, PromosportGrille>();
  for (const g of base) {
    byNumber.set(g.number, g);
  }
  for (const g of extra) {
    const existing = byNumber.get(g.number);
    if (!existing || (existing.status !== 'official' && g.status === 'official')) {
      byNumber.set(g.number, g);
    }
  }
  return Array.from(byNumber.values()).sort((a, b) => b.number - a.number);
}

function parseGrillePayoutsFromHtml(html: string): {
  grilleNumber: number | null;
  cagnotteNum: number;
  cagnotteStr: string;
  winnersNum: number;
  partNum: number;
  partStr: string;
} | null {
  const numMatch = html.match(/Concours(?:\s+International)?\s+N[o°]?\s*(\d{3,4})/i);
  const cagnotteMatch = html.match(/Cagnotte[^0-9]*([\d\s.,]+)\s*(?:Dt|DT|TND)/i);
  const winnersMatch = html.match(/(?:Nombre\s+de\s+)?colonnes?\s+gagnantes?[^0-9]*(\d+)/i);
  const partMatch = html.match(/Part\s+(?:de\s+chaque\s+)?colonne[^0-9]*([\d\s.,]+)\s*(?:Dt|DT|TND)/i);

  if (!numMatch || !cagnotteMatch || !winnersMatch) {
    return null;
  }

  const grilleNumber = Number(numMatch[1]);
  const cagnotteStr = cagnotteMatch[1].trim();
  const cagnotteNum = Number(cagnotteStr.replace(/\s/g, '').replace(',', '.')) || 0;
  const winnersNum = Number(winnersMatch[1]) || 0;
  const partStr = partMatch ? partMatch[1].trim() : '0';
  const partNum = Number(partStr.replace(/\s/g, '').replace(',', '.')) || 0;

  return { grilleNumber, cagnotteNum, cagnotteStr, winnersNum, partNum, partStr };
}

async function fetchSingleRemoteGrille(url: string): Promise<void> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(3500),
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; PromosportTunisieSync/1.0)',
    },
  });
  if (!res.ok) return;

  const html = await res.text();
  const parsed = parseGrillePayoutsFromHtml(html);
  if (parsed && parsed.grilleNumber && parsed.cagnotteNum > 0) {
    const target = syncCache.grilles.find((g) => g.number === parsed.grilleNumber);
    if (target) {
      target.cagnotte = parsed.cagnotteNum;
      target.cagnotteFormatted = `${parsed.cagnotteStr} DT`;
      target.winnersCount = parsed.winnersNum;
      target.winnersFormatted = parsed.winnersNum === 0 ? '0 مرابيح (ترحيل)' : `${parsed.winnersNum} مرابيح`;
      target.prizePerWinner = parsed.partNum;
      target.prizePerWinnerFormatted =
        parsed.winnersNum === 0 ? 'ترحيل الجائزة (0 DT)' : `${parsed.partStr} DT`;
      target.isRollover = parsed.winnersNum === 0;
      target.status = 'official';
      target.sourceUrl = url;
    }
    syncCache.lastRemoteSuccessMs = Date.now();
  }
}

/**
 * Permanently probes http://www.promosportplus.com/grille_int_result.php
 * and per-grille pages for Cagnotte, Colonnes Gagnantes, and Part par Colonne.
 */
async function probeOfficialPromosportSite(): Promise<void> {
  const nowMs = Date.now();
  syncCache.lastAttemptMs = nowMs;

  try {
    const topTargets = [
      'http://www.promosportplus.com/grille_int_result.php',
      ...syncCache.grilles
        .filter((g) => g.number !== syncCache.activeConcours.number)
        .slice(0, 3)
        .map((g) => `http://www.promosportplus.com/grille_int_result.php?grille=${g.number}`),
    ];

    await Promise.allSettled(topTargets.map((url) => fetchSingleRemoteGrille(url)));
  } catch {
    // Cleanly keep authoritative verified official values when isolated offline
  }

  // Evaluate live status of current concours and ensure completed grilles archive cleanly
  const evaluatedConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
  syncCache.activeConcours = evaluatedConcours;

  const archivedExtra: PromosportGrille[] = [];
  if (isConcoursCompletelyFinished(evaluatedConcours, nowMs)) {
    const existing = syncCache.grilles.find((g) => g.number === evaluatedConcours.number);
    archivedExtra.push(archiveConcoursToGrille(evaluatedConcours, existing));
  }

  syncCache.grilles = mergeGrilleList(INITIAL_GRILLES, [...syncCache.grilles, ...archivedExtra]);
  syncCache.syncedAt = new Date(nowMs).toISOString();
}

const execAsync = promisify(exec);
let activeDistBuild: Promise<void> | null = null;

interface ExportDistFile {
  path: string;
  base64: string;
  size: number;
}

async function ensureBuiltDist(): Promise<string> {
  const distDir = path.resolve(__dirname, 'dist');
  const distIndex = path.join(distDir, 'index.html');

  if (!existsSync(distIndex)) {
    if (!activeDistBuild) {
      activeDistBuild = execAsync('npx vite build', {
        cwd: __dirname,
        maxBuffer: 1024 * 1024 * 10,
      })
        .then(() => undefined)
        .finally(() => {
          activeDistBuild = null;
        });
    }
    await activeDistBuild;
  }

  return distDir;
}

async function collectDistFiles(dir: string, rootDir: string, out: ExportDistFile[]): Promise<void> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(rootDir, fullPath).replace(/\\/g, '/');

    // Exclude temporary user-uploaded reference screenshots from exported app bundle
    if (relPath === 'assets/aistudio' || relPath.startsWith('assets/aistudio/')) {
      continue;
    }

    if (entry.isDirectory()) {
      await collectDistFiles(fullPath, rootDir, out);
    } else if (entry.isFile()) {
      const buf = await fs.readFile(fullPath);
      out.push({
        path: relPath,
        base64: buf.toString('base64'),
        size: buf.length,
      });
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Live continuous & scheduled Promosport sync endpoint
  app.get('/api/promosport/sync', async (req, res) => {
    const force = req.query.refresh === '1';
    const ageMs = Date.now() - syncCache.lastAttemptMs;

    // Probe upstream at most once every 30s unless explicitly requested
    if (force || ageMs > 30000) {
      await probeOfficialPromosportSite();
    } else {
      const nowMs = Date.now();
      syncCache.activeConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
      syncCache.syncedAt = new Date(nowMs).toISOString();
    }

    res.setHeader('Cache-Control', 'no-store');
    res.json({
      activeConcours: syncCache.activeConcours,
      grilles: syncCache.grilles,
      syncedAt: syncCache.syncedAt,
      source: syncCache.lastRemoteSuccessMs > 0 ? 'server-live' : 'server-cache',
    });
  });

  // Export compiled production dist/ app bundle for full-app ZIP download
  app.get('/api/export/built-bundle', async (_req, res) => {
    try {
      const distDir = await ensureBuiltDist();
      const files: ExportDistFile[] = [];
      await collectDistFiles(distDir, distDir, files);

      res.setHeader('Cache-Control', 'no-store');
      res.json({
        builtAt: new Date().toISOString(),
        fileCount: files.length,
        files,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Build bundle error';
      res.status(500).json({ error: msg, files: [] });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Promosport Tunisie server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
