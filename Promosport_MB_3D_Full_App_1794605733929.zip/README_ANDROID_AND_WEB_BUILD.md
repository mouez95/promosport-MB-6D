# بروموسبور تونس - MB Football - Complete Archive (Built App + Zero-SDK Cloud APK)

> **تنبيه بيئة البناء:** في حال ظهرت رسالة *"بيئة البناء لا تحتوي على Android SDK و Gradle"*، يحتوي هذا الأرشيف على **التطبيق المبني كاملاً في `dist/`** مع مُشغّل مباشر بدون تثبيت، ومسارات التحويل السحابي إلى `.APK`.

## 0. تشغيل التطبيق المبني الكامل فوراً (بدون تثبيت أو بناء!)
```bash
node start-ready-app.mjs
```
أو افتح الملف `Promosport_MB_3D_Offline_App_934.html` مباشرة في Google Chrome على الهاتف.

## 1. تشغيل التطبيق الكامل من المصدر (Web + PWA + Live Sync Server)
```bash
npm install
npm run build
npm start
```

## 2. فحص البيئة والبناء الآمن (لا يتوقف عند غياب Android SDK)
```bash
node scripts/check-and-build-apk.mjs
```

## 3. التحويل السحابي إلى Android APK (بدون Android SDK أو Gradle محلياً!)
- **الطريقة السحابية A (GitHub Actions - مدمج في الحزمة):**
  ارفع محتوى الـ ZIP إلى GitHub، وسيقوم الملف `.github/workflows/build-android-apk.yml` بتثبيت Java 17 + Android SDK + Gradle 8.9 تلقائياً في السحابة وإخراج ملف `app-debug.apk` جاهز للتحميل من تبويب Actions.
- **الطريقة السحابية B (PWABuilder):**
  افتح الرابط: https://www.pwabuilder.com/?url=https%3A%2F%2Fais-dev-frlvig3bi52fdi4iktajk5-974683008569.europe-west2.run.app واضغط Package for Android لتوليد ملف `.apk` خلال ثوانٍ.

## 4. البناء المحلي (فقط إذا كنت تملك Android Studio + Java 17 + Gradle)
```bash
npm install
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
rm -rf android && npx cap add android && npx cap sync android
cd android && ./gradlew assembleDebug
```
